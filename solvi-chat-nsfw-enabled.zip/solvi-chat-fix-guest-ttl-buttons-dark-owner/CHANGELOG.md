# Changelog

## v1.10.1 — complete SOLVI brand cleanup (2026-11-09)

- Replaced the remaining user-facing SOVLI spelling in store item descriptions, owner notices and runtime labels with SOLVI.

## v1.10.0 — three matching modes and configurable billing (2026-11-09)

- Added separate random matching queues for standard chat, Flirt 18+ and Roleplay 18+.
- Added reciprocal desired-gender matching and roleplay intent pairing (seeking/offering).
- Added separate interest lists for flirt and roleplay while retaining standard chat interests.
- Added server-checked 18+ self-attestation on every adult queue entry; guest accounts are excluded, and the assertion timestamp is preserved across restarts.
- Seeded supplied Telegram and TikTok links, changed visible login branding to SOLVI, and added configurable Stripe currency/prices.
- Note: 18+ self-attestation is not document or identity verification.

## v1.9.1 — SOLVI payments and growth hardening (2026-11-09)

- Added Stripe Checkout for 30-day VIP (€4.99) and Premium (€8.99) subscriptions.
- Added signed Stripe webhook verification with timestamp tolerance, amount/currency/metadata validation and unique payment references to prevent duplicate activation.
- Added a persistent payment ledger visible in the owner growth workspace; webhook payments and owner-verified manual receipts are recorded separately by provider.
- Paid status is distinct from token-earned status. VIP/Premium cosmetic bundles require a current paid entitlement.
- Added user-facing checkout cards with disabled states until Stripe keys and the canonical HTTPS return URL are configured.
- Expanded owner payment reconciliation to require a payment reference and amount.
- Improved owner ticket inbox with search, status/category filters and open-ticket counters.
- Added URL editing for existing social links and payment totals to the owner growth workspace.
- Bumped static asset cache to v24.

## v1.9.0 — SOLVI growth and monetization foundation

- Added owner-managed social links, owner-created reward tasks and manual task-proof review.
- Added max reward counts, rate limits and audited token payouts.
- Improved tickets with open-ticket limits, close action and live reply events.
- Replaced native browser confirmation dialogs with branded SOLVI dialogs.
