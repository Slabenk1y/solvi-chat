'use strict';

const $ = selector => document.querySelector(selector);

function submitChatComposer() {
  const form = document.getElementById('messageForm');
  const input = document.getElementById('messageInput');
  if (!form || !input) return;
  const content = input.value.trim();
  if (!content) return;
  if (!window.__solviChatStateReady) {
    // The normal app boot may still be restoring the session; retain the draft.
    return;
  }
  if (!state.activeMatch) { if (typeof showToast === 'function') showToast('Сначала найди собеседника.'); return; }
  const limit = state.user?.subscriptionTier === 'premium' ? 5000 : (state.user?.subscriptionTier === 'vip' ? 3000 : 2000);
  if (content.length > limit) { showToast(`Сообщение слишком длинное. Лимит: ${limit.toLocaleString('ru-RU')} символов.`); return; }
  const clientId = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  sendMessage(content, clientId);
  input.value = '';
  input.style.height = 'auto';
  saveDraft('');
  const stickerPanel = document.getElementById('stickerPanel');
  if (stickerPanel) stickerPanel.hidden = true;
  state.socket?.emit('chat:typing', { matchId: state.activeMatch?.matchId, typing: false });
}
document.addEventListener('keydown', event => {
  if (event.target?.id !== 'messageInput' || event.key !== 'Enter' || event.shiftKey) return;
  if (window.__solviChatStateReady && state.settings.enterToSend === false) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  submitChatComposer();
}, true);
document.addEventListener('submit', event => {
  if (event.target?.id !== 'messageForm') return;
  event.preventDefault();
  event.stopImmediatePropagation();
  submitChatComposer();
}, true);
document.addEventListener('click', event => {
  if (!event.target?.closest?.('#sendButton')) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  submitChatComposer();
}, true);

const $$ = selector => [...document.querySelectorAll(selector)];
const DEFAULT_AVATARS = ['🪐','🌙','🦊','🐼','🐸','🦉','🐳','🦋','🐙','🌵','🍀','🧩'];
const STICKER_PACKS = {
  'stickers-night-owl': ['✨','🌙','🚀','🫶','👀','🫡','🤝','💫'],
  'stickers-sausage': ['🌭','🐭','🧀','😵‍💫','🥨','💨'],
  'stickers-chaos': ['🤪','🫠','🫨','💥','🙃','🌀'],
  'stickers-food': ['🍔','🍟','🍕','🌮','🍩','🥤'],
  'stickers-sausage-mouse': ['🐭','🌭','🧀','😳','🏃','💨','👑','🥹'],
  'stickers-deep-sea': ['🐠','🐙','🪼','🐬','🦀','🐚'],
  'stickers-vip-comet': ['🌌','💫','🪐','☄️','✨','🌠'],
  'stickers-premium-quantum': ['🪩','🌀','💎','🔮','⚛️','🌌']
};
function safeStorageGet(key) {
  try { return window.localStorage.getItem(key); } catch { return null; }
}
function safeStorageSet(key, value) {
  try { window.localStorage.setItem(key, value); return true; } catch { return false; }
}
function safeStorageRemove(key) {
  try { window.localStorage.removeItem(key); return true; } catch { return false; }
}
function readStoredList(key) {
  try {
    const value = JSON.parse(safeStorageGet(key) || '[]');
    return Array.isArray(value) ? value : [];
  } catch { return []; }
}
const state = {
  // Set after the state object has been initialized.

  token: safeStorageGet('sovli_token') || safeStorageGet('orbit_token') || '',
  user: null,
  ownGender: '', inboxMessages: [], inboxUnread: 0,
  authRestoring: false,
  config: { languages: [], interests: [], avatars: [], matchingEnabled: true, publicMode: false },
  settings: { theme: 'system', sounds: true, soundVolume: 35, messageScale: 'normal', reducedMotion: false, enterToSend: true, compactChat: false, browserNotifications: false },
  soundContext: null,
  settingsSaveTimer: null,
  socket: null,
  activeMatch: null,
  messages: [],
  outbox: [],
  selectedLanguages: readStoredList('sovli_languages').length ? readStoredList('sovli_languages') : ['Русский'],
  selectedInterests: readStoredList('sovli_interests'),
  desiredGender: ['any','male','female'].includes(safeStorageGet('solvi_desired_gender')) ? safeStorageGet('solvi_desired_gender') : 'any',
  selectedAvatar: null,
  authMode: 'login',
  searching: false,
  searchStartedAt: 0,
  searchInterval: null,
  typingTimer: null, lastTypingSentAt: 0, partnerTypingTimer: null, readPending: false, forceScrollToBottom: false,
  toastTimer: null,
  mediaUrls: new Map(),
  mediaLoading: new Set(),
  mediaRecorder: null,
  voiceStream: null,
  voiceChunks: [],
  voiceBlob: null,
  voicePreviewUrl: null,
  voiceStartedAt: 0,
  voiceTimer: null,
  discardVoice: false,
  replyTarget: null,
  storeCategory: 'Все',
  storeCollectionOnly: false,
  storeCollectionFilter: '',
  storeSearch: '',
  storeData: null,
  storePreviewItem: null,
  favorites: [],
  blockedUsers: [],
  tokenHistoryLoaded: false
};
window.__solviChatStateReady = true;

function escapeText(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}
async function appDialog({title='Подтверждение',message='',input=false,defaultValue='',confirmText='Продолжить',danger=false}={}) {
  return new Promise(resolve=>{
    const backdrop=document.createElement('div');backdrop.className='solvi-dialog-backdrop';
    const card=document.createElement('section');card.className='solvi-dialog-card';card.setAttribute('role','dialog');card.setAttribute('aria-modal','true');
    const heading=document.createElement('h2');heading.textContent=title;const copy=document.createElement('p');copy.textContent=message;card.append(heading,copy);
    let field=null;if(input){field=document.createElement('textarea');field.className='solvi-dialog-input';field.rows=3;field.maxLength=500;field.value=defaultValue;card.append(field);}
    const actions=document.createElement('div');actions.className='solvi-dialog-actions';const cancel=document.createElement('button');cancel.type='button';cancel.className='button button-secondary';cancel.textContent='Отмена';const ok=document.createElement('button');ok.type='button';ok.className='button '+(danger?'button-danger':'button-primary');ok.textContent=confirmText;actions.append(cancel,ok);card.append(actions);backdrop.append(card);document.body.append(backdrop);
    const finish=value=>{backdrop.remove();window.removeEventListener('keydown',key);resolve(value);};const key=e=>{if(e.key==='Escape')finish(null);if(e.key==='Enter'&&!input)finish(true);};cancel.onclick=()=>finish(null);ok.onclick=()=>finish(input?field.value.trim():true);backdrop.onclick=e=>{if(e.target===backdrop)finish(null);};window.addEventListener('keydown',key);if(field)field.focus();
  });
}
function showToast(message, duration = 2800) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.classList.remove('show'), duration);
}

function formatCashStorePrice(priceMinor, currency) {
  const amount = Number(priceMinor || 0) / 100;
  const code = String(currency || 'EUR').toUpperCase();
  try { return new Intl.NumberFormat('ru-RU', { style: 'currency', currency: code }).format(amount); }
  catch { return amount.toFixed(2) + ' ' + code; }
}
function confirmManualCashPurchase(item) {
  const modal = $('#cashPurchaseModal');
  $('#cashPurchaseTitle').textContent = 'Покупка за реальные деньги';
  $('#cashPurchaseItem').textContent = item.name;
  $('#cashPurchasePrice').textContent = formatCashStorePrice(item.cashPriceMinor, item.cashCurrency);
  $('#cashPurchaseNote').textContent = 'Сначала создастся заявка. Оплата вручную согласуется с владельцем; деньги здесь не списываются. После проверки оплаты владелец выдаст товар.';
  $('#cashPurchaseSubmit').hidden = false;
  $('#cashPurchaseSubmit').textContent = 'Создать заявку';
  $('#cashPurchaseCancel').textContent = 'Отмена';
  if (modal.parentElement !== document.body) document.body.append(modal);
  modal.hidden = false;
  return new Promise(resolve => {
    let settled = false;
    const finish = value => {
      if (settled) return;
      settled = true; modal.hidden = true;
      $('#cashPurchaseCancel').onclick = null;
      $('#cashPurchaseSubmit').onclick = null;
      modal.onclick = null;
      window.removeEventListener('keydown', onKeyDown);
      resolve(value);
    };
    const onKeyDown = event => { if (event.key === 'Escape') finish(false); };
    $('#cashPurchaseCancel').onclick = () => finish(false);
    $('#cashPurchaseSubmit').onclick = () => finish(true);
    modal.onclick = event => { if (event.target === modal) finish(false); };
    window.addEventListener('keydown', onKeyDown);
  });
}
async function requestManualCashPurchase(item) {
  const approved = await confirmManualCashPurchase(item);
  if (!approved) return;
  const button = $('#cashPurchaseSubmit');
  button.disabled = true; button.textContent = 'Создаём заявку…';
  try {
    const result = await api('/api/billing/manual-store/orders', { method: 'POST', body: JSON.stringify({ itemId: item.id }) });
    $('#cashPurchaseModal').hidden = true;
    showToast('Заявка ' + result.orderId + ' создана. Владелец увидит её в панели.');
    if (result.telegramUrl) { window.location.assign(result.telegramUrl); return; }
    if (result.contactUrl) { window.location.assign(result.contactUrl); return; }
    $('#cashPurchaseNote').textContent = 'Заявка ' + result.orderId + ' сохранена. Владелец увидит её в панели SOLVI. Бот пока не подключён — свяжись с владельцем отдельно.';
    $('#cashPurchaseSubmit').hidden = true;
    const modal = $('#cashPurchaseModal');
    const doneButton = $('#cashPurchaseCancel');
    doneButton.textContent = 'Понятно';
    doneButton.onclick = () => {
      modal.hidden = true;
      doneButton.onclick = null;
      modal.onclick = null;
    };
    modal.onclick = event => {
      if (event.target === modal) {
        modal.hidden = true;
        doneButton.onclick = null;
        modal.onclick = null;
      }
    };
    $('#cashPurchaseModal').hidden = false;
  } catch (error) {
    showToast(error.message); $('#cashPurchaseModal').hidden = true;
  } finally { button.disabled = false; button.textContent = 'Создать заявку'; }
}
function confirmStorePurchase({ title, description, price, balance, confirmLabel = 'Купить' }) {
  const modal = $('#purchaseConfirmModal');
  const cost = Math.max(0, Number(price) || 0);
  const wallet = Math.max(0, Number(balance) || 0);
  const enough = wallet >= cost;
  $('#purchaseConfirmTitle').textContent = title;
  $('#purchaseConfirmDescription').textContent = description || 'Покупка навсегда останется в твоём инвентаре.';
  $('#purchaseConfirmPrice').textContent = `${cost.toLocaleString('ru-RU')} ✦`;
  $('#purchaseConfirmBalance').textContent = `${wallet.toLocaleString('ru-RU')} ✦`;
  $('#purchaseConfirmShortfall').hidden = enough;
  $('#purchaseConfirmShortfall').textContent = `Не хватает ${(cost - wallet).toLocaleString('ru-RU')} токенов. Продолжай общаться, чтобы заработать их.`;
  if (modal.parentElement !== document.body) document.body.append(modal);
  document.body.classList.add('purchase-confirm-open');
  const confirm = $('#purchaseConfirmButton');
  confirm.disabled = !enough;
  confirm.textContent = enough ? confirmLabel : 'Не хватает токенов';
  modal.hidden = false;
  return new Promise(resolve => {
    let settled = false;
    const finish = value => {
      if (settled) return;
      settled = true;
      modal.hidden = true;
      document.body.classList.remove('purchase-confirm-open');
      $('#purchaseCancelButton').onclick = null;
      confirm.onclick = null;
      modal.onclick = null;
      window.removeEventListener('keydown', onKeyDown);
      resolve(value);
    };
    const onKeyDown = event => { if (event.key === 'Escape') finish(false); };
    $('#purchaseCancelButton').onclick = () => finish(false);
    confirm.onclick = () => finish(true);
    modal.onclick = event => { if (event.target === modal) finish(false); };
    window.addEventListener('keydown', onKeyDown);
  });
}

function applyEquipped(equipped = {}) {
  const root = document.documentElement;
  root.dataset.storeTheme = equipped.theme || equipped.wallpaper || 'theme-light';
  delete root.dataset.storeWallpaper;
  root.dataset.storeBubble = equipped.bubble || '';
  root.dataset.storeFrame = equipped.frame || '';
  root.dataset.storeSound = equipped.sound || '';
  root.dataset.storeStickers = equipped.stickers || '';
  root.dataset.storeTitle = equipped.title || '';
  applyTheme();
}
function createStorePreview(item) {
  const preview = document.createElement('div');
  preview.className = `store-item-preview preview-${item.preview}`;
  const safeValue = String(item.value || '').toLowerCase().replace(/[^a-z0-9-]/g, '');
  const scene = document.createElement('div');
  scene.className = `store-preview-scene scene-${item.slot}`;
  if (item.slot === 'theme' || item.slot === 'wallpaper') {
    const windowCard = document.createElement('div'); windowCard.className = 'preview-window-card';
    const top = document.createElement('div'); top.className = 'preview-window-top';
    ['one','two','three'].forEach(name => { const dot = document.createElement('i'); dot.className = `preview-dot ${name}`; top.append(dot); });
    const lines = document.createElement('div'); lines.className = 'preview-window-lines';
    const bubbleA = document.createElement('span'); bubbleA.className = 'preview-line preview-line-a'; bubbleA.textContent = 'Привет!';
    const bubbleB = document.createElement('span'); bubbleB.className = 'preview-line preview-line-b'; bubbleB.textContent = 'Как дела?';
    lines.append(bubbleA, bubbleB); windowCard.append(top, lines); scene.append(windowCard);
  } else if (item.slot === 'bubble') {
    const left = document.createElement('span'); left.className = 'preview-chat-bubble preview-chat-in'; left.textContent = 'Привет';
    const right = document.createElement('span'); right.className = 'preview-chat-bubble preview-chat-out'; right.textContent = 'Привет! ✨';
    scene.append(left, right);
  } else if (item.slot === 'frame') {
    const avatar = document.createElement('span'); avatar.className = `preview-avatar preview-frame-${safeValue}`; avatar.textContent = '◉';
    const caption = document.createElement('span'); caption.className = 'preview-avatar-caption'; caption.textContent = 'Твой профиль';
    scene.append(avatar, caption);
  } else if (item.slot === 'sound') {
    const sound = document.createElement('div'); sound.className = 'preview-sound-bars';
    [16,28,40,22,34,14,31,20,12].forEach((height, index) => { const bar = document.createElement('i'); bar.style.setProperty('--bar-height', `${height}px`); bar.style.setProperty('--bar-delay', `${index * 0.08}s`); sound.append(bar); });
    const label = document.createElement('span'); label.className = 'preview-sound-caption'; label.textContent = 'Звук интерфейса'; scene.append(sound, label);
  } else if (item.slot === 'stickers') {
    const stickers = document.createElement('div'); stickers.className = 'preview-sticker-stack';
    (STICKER_PACKS[item.id] || ['🌙','✨','☕']).slice(0,3).forEach((symbol, index) => { const sticker = document.createElement('span'); sticker.textContent = symbol; sticker.style.setProperty('--sticker-shift', `${(1 - index) * 5}px`); sticker.style.setProperty('--sticker-rotate', `${(index - 1) * 9}deg`); stickers.append(sticker); });
    scene.append(stickers);
  } else if (item.slot === 'title') {
    const title = document.createElement('span'); title.className = 'preview-title-pill'; title.textContent = item.name; scene.append(title);
  } else {
    const fallback = document.createElement('span'); fallback.className = 'preview-title-pill'; fallback.textContent = 'SOLVI'; scene.append(fallback);
  }
  preview.append(scene);
  return preview;
}
function createThemeStorePreview(item) {
  const palettes = {
    aurora: ['#101d34','#1b3150','#79d7ca','#f2fbff','#a8bfd2'],
    sunset: ['#30232b','#50343b','#f09b78','#fff3eb','#d9b9ae'],
    midnight: ['#151525','#222139','#9f88f4','#f2efff','#b1a9ca'],
    candy: ['#321e38','#512b55','#ec83c0','#fff0fa','#d7b8d4'],
    arcade: ['#142a35','#1c3c49','#20c6d1','#eaffff','#a7cdd2'],
    cream: ['#fbf5e9','#fffaf0','#bc8b57','#514333','#96846d'],
    ice: ['#eff7fb','#fbfeff','#4c9ec6','#253d52','#7c9bb0'],
    sakura: ['#fff5f8','#fffafd','#d57fa7','#55384a','#a17b90'],
    violet: ['#241d3b','#382c55','#a47ce9','#f5efff','#c3b1dd'],
    space: ['#111b31','#1c2b49','#8f83ee','#f2efff','#a9abc9'],
    paper: ['#eee5d5','#fffaf0','#ad825b','#514333','#96846d'],
    neon: ['#101b2b','#172c43','#43d5e7','#e9fbff','#9dbdca'],
    pixel: ['#18263a','#263a54','#e1a64b','#fff5dc','#b9c6d8'],
    clouds: ['#e9f2fa','#ffffff','#6fa9d0','#31475c','#8ba1b3'],
    default: ['#f2f1f8','#ffffff','#8278d8','#302d45','#918ca7'],
    'vip-nebula': ['#101a2e','#172941','#72c9d6','#eafaff','#9ab9cf'],
    'premium-event-horizon': ['#171027','#24183a','#c78cff','#fff5ff','#c4aed8'],
    dark: ['#181827','#232337','#8d86ff','#f0efff','#a2a2ba'],
    light: ['#f5f6fb','#ffffff','#756ee8','#29263e','#88859e']
  };
  const paletteAliases = { royal: 'violet', mint: 'clouds', berry: 'candy', lilac: 'violet', gold: 'cream', orbit: 'space', comet: 'space', soft: 'clouds', night: 'midnight', ocean: 'ice', flower: 'sakura', rain: 'clouds', rose: 'sakura', mountain: 'sunset', cyber: 'neon', sea: 'ice', citrus: 'sunset', graphite: 'midnight', glass: 'ice', bubble: 'candy', synth: 'arcade', 'deep-sea': 'ice', 'first-contact': 'aurora', 'sakura-keeper': 'sakura', 'night-circuit': 'neon' };
  const colors = palettes[item.value] || palettes[paletteAliases[item.value]] || palettes.default;
  const root = document.createElement('div');
  root.className = 'store-detail-preview theme-context-preview';
  root.style.setProperty('--mock-bg', colors[0]);
  root.style.setProperty('--mock-surface', colors[1]);
  root.style.setProperty('--mock-accent', colors[2]);
  root.style.setProperty('--mock-ink', colors[3]);
  root.style.setProperty('--mock-muted', colors[4]);
  const shell = document.createElement('div'); shell.className = 'theme-mock-shell';
  const top = document.createElement('div'); top.className = 'theme-mock-top';
  const brand = document.createElement('strong'); brand.textContent = 'SOLVI';
  const topLabel = document.createElement('span'); topLabel.textContent = 'ТВОЁ ПРОСТРАНСТВО';
  top.append(brand, topLabel);
  const body = document.createElement('div'); body.className = 'theme-mock-body';
  const rail = document.createElement('aside'); rail.className = 'theme-mock-rail';
  ['◉','⌕','♡','⚙'].forEach((symbol,index)=>{const icon=document.createElement('i');icon.textContent=symbol;if(index===0)icon.className='active';rail.append(icon);});
  const chat = document.createElement('div'); chat.className = 'theme-mock-chat';
  const heading = document.createElement('div'); heading.className = 'theme-mock-heading';
  const avatar = document.createElement('span'); avatar.className='theme-mock-avatar';avatar.textContent=state.user?.avatar || '🌙';
  const headingCopy = document.createElement('div'); const name=document.createElement('strong');name.textContent=state.user?.username || 'Твой ник';const online=document.createElement('small');online.textContent='● В сети';headingCopy.append(name,online);heading.append(avatar,headingCopy);
  const messages=document.createElement('div');messages.className='theme-mock-messages';
  const incoming=document.createElement('span');incoming.className='theme-mock-bubble incoming';incoming.textContent='Привет! Как настроение?';
  const outgoing=document.createElement('span');outgoing.className='theme-mock-bubble outgoing';outgoing.textContent='Отличное ✨ А у тебя?';
  const incoming2=document.createElement('span');incoming2.className='theme-mock-bubble incoming';incoming2.textContent='Теперь ещё лучше :)';
  messages.append(incoming,outgoing,incoming2);
  const composer=document.createElement('div');composer.className='theme-mock-composer';composer.textContent='Написать сообщение…';
  const profile=document.createElement('div');profile.className='theme-mock-profile';
  const profileAvatar=document.createElement('span');profileAvatar.textContent=state.user?.avatar || '🌙';
  const profileName=document.createElement('strong');profileName.textContent=state.user?.username || 'Твой ник';
  const profileStatus=document.createElement('small');profileStatus.textContent='ТВОЙ ПРОФИЛЬ';
  profile.append(profileAvatar,profileName,profileStatus);
  chat.append(heading,messages,composer,profile);body.append(rail,chat);shell.append(top,body);root.append(shell);
  return root;
}
function openStorePreview(item) {
  state.storePreviewItem = item;
  const modal = $('#storePreviewModal');
  const visual = $('#storePreviewCanvas');
  visual.replaceChildren();
  if (item.slot === 'membership') {
    const tier = item.tier === 'premium' ? 'premium' : 'vip';
    const showcase = document.createElement('div'); showcase.className = `membership-showcase membership-showcase-${tier}`;
    const top = document.createElement('div'); top.className = 'membership-showcase-top';
    const avatar = document.createElement('div'); avatar.className = 'membership-showcase-avatar'; avatar.textContent = '✦';
    const identity = document.createElement('div'); identity.className = 'membership-showcase-identity';
    const username = document.createElement('strong'); username.textContent = 'Твой ник';
    const badge = document.createElement('span'); badge.className = 'membership-showcase-badge'; badge.textContent = tier === 'premium' ? '✦ PREMIUM' : '✧ VIP';
    identity.append(username, badge); top.append(avatar, identity);
    const chat = document.createElement('div'); chat.className = 'membership-showcase-chat';
    const incoming = document.createElement('span'); incoming.className = 'membership-demo-message incoming'; incoming.textContent = 'Привет! Как настроение?';
    const outgoing = document.createElement('span'); outgoing.className = 'membership-demo-message outgoing'; outgoing.textContent = 'Отлично, теперь мой профиль сияет ✨';
    chat.append(incoming, outgoing);
    const perks = document.createElement('div'); perks.className = 'membership-showcase-perks';
    const perkNames = tier === 'premium' ? ['Всё из VIP', '5 000 символов', '10 фото до 12 МБ', 'Голосовые до 1 минуты', 'Аватар до 12 МБ', 'Русский язык', 'До 12 интересов', 'Квантовый набор кастомизаций'] : ['VIP-значок и рамка', '3 000 символов', '5 фото до 8 МБ', 'Голосовые до 45 секунд', 'Аватар до 8 МБ', 'Русский язык', 'До 8 интересов', 'Набор «Звёздный след»'];
    perkNames.forEach(name => { const chip = document.createElement('span'); chip.textContent = '✓ ' + name; perks.append(chip); });
    showcase.append(top, chat, perks); visual.append(showcase);
  } else if (item.slot === 'theme' || item.slot === 'wallpaper') {
    visual.append(createThemeStorePreview(item));
  } else {
    const preview = createStorePreview(item);
    preview.classList.add('store-detail-preview');
    visual.append(preview);
  }
  $('#storePreviewBadge').textContent = item.category || (item.tier === 'premium' ? 'PREMIUM' : 'VIP');
  $('#storePreviewTitle').textContent = item.name || 'Предпросмотр';
  $('#storePreviewDescription').textContent = item.description || 'Посмотри, как предмет будет выглядеть в SOLVI.';
  const effects = {
    theme: 'Полностью меняет оформление SOLVI: фон, палитру, панели, карточки и область диалога.',
    bubble: 'Меняет цвет и визуальный стиль твоих исходящих сообщений.',
    frame: 'Добавляет декоративную рамку к аватару профиля.',
    sound: 'Меняет короткий звуковой сигнал интерфейса.',
    stickers: 'Открывает дополнительный набор стикеров в панели отправки.',
    title: 'Показывает выбранный титул рядом с твоим именем.',
    membership: item.tier === 'premium'
      ? 'Premium включает VIP, усиливает оформление профиля и расширяет лимиты: 5 000 символов, 10 фото до 12 МБ, голосовые до 1 минуты, аватар до 12 МБ, русский язык и до 12 интересов. Небольшой приоритет поиска после владельца — до 8 секунд.'
      : 'VIP добавляет значок и сияющую рамку профиля, 3 000 символов, 5 фото до 8 МБ, голосовые до 45 секунд, аватар до 8 МБ, русский язык и до 8 интересов. Небольшой приоритет поиска после владельца и Premium — до 4 секунд.'
  };
  $('#storePreviewBenefit').textContent = effects[item.slot] || 'Добавляет этот предмет в твою коллекцию оформления.';
  const previewPrices = [];
  if (item.tokenEnabled !== false) previewPrices.push(Number(item.price || 0).toLocaleString('ru-RU') + ' ✦');
  if (item.cashEnabled && Number(item.cashPriceMinor) >= 30) previewPrices.push(formatCashStorePrice(item.cashPriceMinor, item.cashCurrency));
  $('#storePreviewPrice').textContent = previewPrices.join(' · ') || 'Цена не задана';
  if (item.slot === 'membership') {
    const duration = document.createElement('p'); duration.className = 'store-preview-duration';
    duration.textContent = `Срок: ${item.hours || 1} ч. · ${item.tier === 'premium' ? '360 ✦ = 6 часов' : '180 ✦ = 3 часа'} активного диалога за каждый час статуса. При повторной покупке время прибавляется к остатку.`;
    $('#storePreviewBenefit').append(duration);
  }
  if (modal.parentElement !== document.body) document.body.append(modal);
  document.body.classList.add('store-preview-open');
  modal.hidden = false;
}
function renderStore(data) {
  state.storeData = data;
  $('#storeBalance').textContent = Number(data.balance || 0).toLocaleString('ru-RU');
  const categories = $('#storeCategories');
  categories.replaceChildren();
  (data.categories || ['Все']).forEach(category => {
    const button = document.createElement('button');
    button.type = 'button'; button.className = `store-category${state.storeCategory === category ? ' active' : ''}`;
    button.textContent = category;
    button.addEventListener('click', () => { state.storeCategory = category; state.storeCollectionOnly = false; renderStore(data); });
    categories.append(button);
  });
  const collectionSelect = $('#storeCollectionSelect');
  if (collectionSelect) {
    const selected = state.storeCollectionFilter;
    collectionSelect.replaceChildren(new Option('Все коллекции', ''));
    (data.collections || []).forEach(collection => collectionSelect.add(new Option(`${collection.name} · ${collection.owned}/${collection.total}`, collection.name)));
    collectionSelect.value = selected;
  }
  const search = $('#storeSearchInput');
  if (search && search.value !== state.storeSearch) search.value = state.storeSearch;
  $('#storeInventoryButton').classList.toggle('active', state.storeCollectionOnly);
  $('#storeInventoryButton').textContent = state.storeCollectionOnly ? 'Весь каталог' : 'Только купленное';
  $('#storeEquippedSummary').replaceChildren();
  const slotLabels = { theme: 'Тема интерфейса', bubble: 'Сообщения', frame: 'Рамка', sound: 'Звук', stickers: 'Стикеры', title: 'Титул' };
  Object.entries(slotLabels).forEach(([slot, label]) => {
    const itemId = data.equipped?.[slot];
    const item = data.items.find(row => row.id === itemId);
    const chip = document.createElement('span'); chip.className = 'equipped-chip';
    chip.textContent = `${label}: ${item?.name || 'По умолчанию'}`;
    $('#storeEquippedSummary').append(chip);
  });
  const collectionsRoot = $('#storeCollections');
  collectionsRoot.replaceChildren();
  (data.collections || []).forEach(collection => {
    const card = document.createElement('button'); card.type = 'button';
    card.className = `collection-card${state.storeCollectionFilter === collection.name ? ' active' : ''}`;
    const title = document.createElement('strong'); title.textContent = collection.name;
    const progress = document.createElement('span'); progress.textContent = `${collection.owned} из ${collection.total} предметов`;
    const track = document.createElement('i'); const fill = document.createElement('b'); fill.style.width = `${collection.total ? Math.min(100, collection.owned / collection.total * 100) : 0}%`; track.append(fill);
    card.append(title, progress, track);
    card.addEventListener('click', () => { state.storeCollectionFilter = state.storeCollectionFilter === collection.name ? '' : collection.name; renderStore(data); });
    collectionsRoot.append(card);
  });
  const root = $('#storeItems'); root.replaceChildren();
  const query = state.storeSearch.trim().toLocaleLowerCase('ru-RU');
  const visible = data.items.filter(item => !item.bundleOnly && item.enabled !== false && (state.storeCategory === 'Все' || item.category === state.storeCategory) && (!state.storeCollectionOnly || item.owned) && (!state.storeCollectionFilter || item.collection === state.storeCollectionFilter) && (!query || `${item.name} ${item.description} ${item.collection}`.toLocaleLowerCase('ru-RU').includes(query)));
  if (!visible.length) { const empty = document.createElement('div'); empty.className = 'store-empty'; empty.textContent = state.storeCollectionOnly ? 'В этой категории пока нет купленных предметов.' : 'Ничего не найдено. Попробуй изменить фильтр.'; root.append(empty); }
  visible.forEach(item => {
    const card = document.createElement('article'); card.className = `store-item-card rarity-${String(item.rarity).toLowerCase()}`;
    const preview = createStorePreview(item);
    const meta = document.createElement('div'); meta.className = 'store-item-meta';
    const category = document.createElement('span'); category.className = 'store-item-category'; category.textContent = `${item.category} · ${item.rarity}`;
    const title = document.createElement('h3'); title.textContent = item.name;
    const description = document.createElement('p'); description.textContent = item.description;
    const collection = document.createElement('small'); collection.className = 'store-item-collection'; collection.textContent = `Коллекция: ${item.collection || 'SOLVI'}`;
    meta.append(category, title, description, collection);
    const footer = document.createElement('div'); footer.className = 'store-item-footer';
    const prices = document.createElement('div'); prices.className = 'store-price-stack';
    const price = document.createElement('strong'); price.className = 'store-item-price';
    price.textContent = item.owned ? (item.equipped ? 'Уже используется' : 'В коллекции')
      : (item.tokenEnabled === false ? 'Токены недоступны' : `${Number(item.price).toLocaleString('ru-RU')} ✦`);
    prices.append(price);
    if (!item.owned && item.cashEnabled && Number(item.cashPriceMinor) >= 30) {
      const cashPrice = document.createElement('span'); cashPrice.className = 'store-cash-price';
      cashPrice.textContent = formatCashStorePrice(item.cashPriceMinor, item.cashCurrency); prices.append(cashPrice);
    }
    const previewButton = document.createElement('button'); previewButton.type = 'button'; previewButton.className = 'store-preview-button'; previewButton.textContent = 'Предпросмотр';
    previewButton.addEventListener('click', () => openStorePreview(item));
    const actions = document.createElement('div'); actions.className = 'store-purchase-actions';
    if (item.equipped || item.owned || item.tokenEnabled !== false) {
      const action = document.createElement('button'); action.type = 'button'; action.className = 'button button-secondary store-action';
      if (item.equipped) action.textContent = 'Снять';
      else if (item.owned) action.textContent = 'Применить';
      else action.textContent = 'За токены';
      action.addEventListener('click', async () => {
        action.disabled = true;
        try {
          if (item.equipped) {
            const result = await api(`/api/store/equip/${encodeURIComponent(item.slot)}`, { method: 'DELETE' });
            applyEquipped(result.equipped); if (state.user) state.user.equipped = result.equipped;
            renderStickerPanel(); showToast(`Снято: ${item.name}.`);
          } else if (!item.owned) {
            const approved = await confirmStorePurchase({ title: `Купить «${item.name}» за токены?`, description: item.description, price: item.price, balance: data.balance });
            if (!approved) { action.disabled = false; return; }
            const result = await api('/api/store/buy', { method: 'POST', body: JSON.stringify({ itemId: item.id }) });
            if (state.user) state.user.tokens = result.balance;
            showToast(`«${item.name}» добавлен в коллекцию.`);
          } else {
            const result = await api('/api/store/equip', { method: 'POST', body: JSON.stringify({ itemId: item.id }) });
            applyEquipped(result.equipped); if (state.user) state.user.equipped = result.equipped;
            renderStickerPanel(); showToast(`Применено: ${item.name}.`);
          }
          await loadStore();
        } catch (error) { showToast(error.message); action.disabled = false; }
      });
      actions.append(action);
    }
    if (!item.owned && item.cashEnabled && Number(item.cashPriceMinor) >= 30) {
      const cashAction = document.createElement('button'); cashAction.type = 'button';
      cashAction.className = 'button button-primary store-cash-action'; cashAction.textContent = 'За деньги';
      cashAction.addEventListener('click', () => requestManualCashPurchase(item)); actions.append(cashAction);
    }
    footer.append(previewButton, prices, actions);
    card.append(preview, meta, footer); root.append(card);
  });
  const bundleRoot = $('#customizationBundles');
  bundleRoot.replaceChildren();
  (data.bundles || []).forEach(bundle => {
    const card = document.createElement('article'); card.className = `bundle-card bundle-${bundle.tier}`;
    const label = document.createElement('span'); label.className = 'bundle-kicker'; label.textContent = bundle.tier === 'premium' ? 'PREMIUM · МИФИЧЕСКАЯ СЕРИЯ' : 'VIP · ЛЕГЕНДАРНАЯ СЕРИЯ';
    const title = document.createElement('h3'); title.textContent = bundle.name;
    const copy = document.createElement('p'); copy.textContent = bundle.description;
    const contents = document.createElement('div'); contents.className = 'bundle-contents';
    bundle.itemIds.forEach(id => { const item = data.items.find(entry => entry.id === id); if (item) { const chip = document.createElement('span'); chip.textContent = `${item.name} · ${item.category}`; contents.append(chip); } });
    const footer = document.createElement('div'); footer.className = 'bundle-footer';
    const prices = document.createElement('div'); prices.className = 'store-price-stack';
    if (bundle.tokenEnabled !== false) { const price = document.createElement('strong'); price.textContent = `${Number(bundle.price).toLocaleString('ru-RU')} ✦`; prices.append(price); }
    if (bundle.cashEnabled && Number(bundle.cashPriceMinor) >= 30) { const cashPrice = document.createElement('span'); cashPrice.className = 'store-cash-price'; cashPrice.textContent = formatCashStorePrice(bundle.cashPriceMinor,bundle.cashCurrency); prices.append(cashPrice); }
    const actions = document.createElement('div'); actions.className = 'store-purchase-actions';
    const button = document.createElement('button'); button.type = 'button'; button.className = 'button button-secondary';
    button.textContent = bundle.owned ? 'Уже в коллекции' : (bundle.tokenEnabled === false ? 'Токены недоступны' : (bundle.available ? 'За токены' : 'Нужен статус'));
    button.disabled = bundle.owned || !bundle.available || bundle.tokenEnabled === false;
    button.addEventListener('click', async () => {
      const approved = await confirmStorePurchase({ title: `Купить ${bundle.name} за токены?`, description: bundle.description, price: bundle.price, balance: data.balance, confirmLabel: 'Забрать набор' });
      if (!approved) return;
      button.disabled = true;
      try { const result = await api('/api/store/bundle', { method: 'POST', body: JSON.stringify({ bundleId: bundle.id }) }); if (state.user) state.user.tokens = result.balance; showToast(`${bundle.name}: предметы добавлены в инвентарь.`); await loadStore(); }
      catch (error) { showToast(error.message); button.disabled = false; }
    });
    actions.append(button);
    if (!bundle.owned && bundle.cashEnabled && Number(bundle.cashPriceMinor) >= 30) {
      const cashButton = document.createElement('button'); cashButton.type = 'button'; cashButton.className = 'button button-primary store-cash-action'; cashButton.textContent = 'За деньги'; cashButton.addEventListener('click', () => requestManualCashPurchase(bundle)); actions.append(cashButton);
    }
    footer.append(prices, actions);
    card.append(label, title, copy, contents, footer); bundleRoot.append(card);
  });
  const membershipRoot = $('#membershipOffers'); membershipRoot.replaceChildren();
  (data.memberships || []).forEach(pack => {
    const card = document.createElement('article'); card.className = `membership-card membership-${pack.tier}`;
    const label = document.createElement('span'); label.className = 'membership-kicker'; label.textContent = pack.tier === 'premium' ? 'МАКСИМАЛЬНЫЙ СТАТУС' : 'РАСШИРЕННЫЙ СТАТУС';
    const title = document.createElement('h3'); title.textContent = pack.name;
    const copy = document.createElement('p'); copy.textContent = pack.description;
    const prices = document.createElement('div'); prices.className = 'store-price-stack membership-price-stack';
    if (pack.tokenEnabled !== false) { const price = document.createElement('strong'); price.textContent = `${Number(pack.price).toLocaleString('ru-RU')} ✦`; prices.append(price); }
    if (pack.cashEnabled && Number(pack.cashPriceMinor) >= 30) { const cashPrice = document.createElement('span'); cashPrice.className = 'store-cash-price'; cashPrice.textContent = formatCashStorePrice(pack.cashPriceMinor,pack.cashCurrency); prices.append(cashPrice); }
    const previewButton = document.createElement('button'); previewButton.type = 'button'; previewButton.className = 'store-preview-button'; previewButton.textContent = 'Что входит';
    previewButton.addEventListener('click', () => openStorePreview({ ...pack, slot: 'membership', description: pack.description + ' Срок добавится к уже активной привилегии.' }));
    const actions = document.createElement('div'); actions.className = 'store-purchase-actions';
    if (pack.tokenEnabled !== false) {
      const button = document.createElement('button'); button.type = 'button'; button.className = 'button button-secondary'; button.textContent = 'За токены';
      button.addEventListener('click', async () => {
        const approved = await confirmStorePurchase({ title: `Оформить ${pack.name} за токены?`, description: `${pack.description} Срок добавится к уже активной привилегии.`, price: pack.price, balance: state.storeData?.balance ?? state.user?.tokens ?? 0, confirmLabel: 'Подтвердить покупку' });
        if (!approved) return;
        button.disabled = true;
        try { const result = await api('/api/store/membership', { method: 'POST', body: JSON.stringify({ packageId: pack.id }) }); setUser(result.user); showToast(`${pack.name} активирован.`); await loadStore(); }
        catch (error) { showToast(error.message); button.disabled = false; }
      });
      actions.append(button);
    }
    if (pack.cashEnabled && Number(pack.cashPriceMinor) >= 30) {
      const cashButton = document.createElement('button'); cashButton.type = 'button'; cashButton.className = 'button button-primary store-cash-action'; cashButton.textContent = 'За деньги'; cashButton.addEventListener('click', () => requestManualCashPurchase(pack)); actions.append(cashButton);
    }
    card.append(label, title, copy, previewButton, prices, actions);
    membershipRoot.append(card);
  });
}
async function loadInventory() {
  try {
    const data = await api('/api/inventory');
    if (state.user) state.user.equipped = data.equipped || {};
    applyEquipped(data.equipped || {});
    $('#inventoryBalance').textContent = Number(data.balance || 0).toLocaleString('ru-RU');
    $('#inventoryCount').textContent = `${data.items.length} предметов`;
    const root = $('#inventoryItems'); root.replaceChildren();
    if (!data.items.length) { const empty = document.createElement('div'); empty.className = 'store-empty'; empty.textContent = 'Коллекция пока пуста. Загляни в магазин и выбери первый предмет.'; root.append(empty); return; }
    data.items.forEach(item => {
      const card = document.createElement('article'); card.className = 'store-item-card inventory-card';
      card.append(createStorePreview(item));
      const meta = document.createElement('div'); meta.className = 'store-item-meta';
      const category = document.createElement('span'); category.className = 'store-item-category'; category.textContent = `${item.category} · ${item.rarity}`;
      const title = document.createElement('h3'); title.textContent = item.name;
      const desc = document.createElement('p'); desc.textContent = item.description;
      const source = document.createElement('small'); source.className = 'store-item-collection'; source.textContent = `Получено: ${item.source === 'promo' ? 'промокод' : item.source === 'purchase' ? 'покупка' : item.source === 'manual-cash-purchase' ? 'покупка за деньги' : item.source === 'cash-purchase' ? 'покупка за деньги' : item.source === 'starter' ? 'стартовый предмет' : item.source === 'ai-gift' ? 'подарок от ИИ' : 'коллекция'} · ${new Date(item.acquiredAt).toLocaleDateString('ru-RU')}`;
      meta.append(category, title, desc, source);
      const footer = document.createElement('div'); footer.className = 'store-item-footer';
      const label = document.createElement('strong'); label.className = 'store-item-price'; label.textContent = item.equipped ? 'Используется' : 'В коллекции';
      const button = document.createElement('button'); button.type = 'button'; button.className = 'button button-secondary store-action'; button.textContent = item.equipped ? 'Снять' : 'Применить';
      button.addEventListener('click', async () => {
        button.disabled = true;
        try {
          const result = item.equipped
            ? await api(`/api/store/equip/${encodeURIComponent(item.slot)}`, { method: 'DELETE' })
            : await api('/api/store/equip', { method: 'POST', body: JSON.stringify({ itemId: item.id }) });
          if (state.user) state.user.equipped = result.equipped;
          applyEquipped(result.equipped); renderStickerPanel(); await loadInventory();
          showToast(item.equipped ? 'Предмет снят.' : 'Предмет применён.');
        } catch (error) { showToast(error.message); button.disabled = false; }
      });
      footer.append(label, button); card.append(meta, footer); root.append(card);
    });
  } catch (error) { showToast(error.message); }
}
async function redeemPromo() {
  const input = $('#promoCodeInput'); const button = $('#promoRedeemButton');
  $('#promoRedeemError').textContent = '';
  button.disabled = true;
  try {
    const result = await api('/api/promos/redeem', { method: 'POST', body: JSON.stringify({ code: input.value }) });
    setUser(result.user); input.value = '';
    $('#promoRedeemError').textContent = 'Промокод успешно активирован.';
    $('#promoRedeemError').classList.add('success-text');
    showToast('Награда промокода добавлена.');
    await loadStore();
  } catch (error) { $('#promoRedeemError').classList.remove('success-text'); $('#promoRedeemError').textContent = error.message; }
  finally { button.disabled = false; }
}
async function loadSponsoredAd(placement, selector){
  const root=$(selector);if(!root)return;
  try{
    const result=await api('/api/ads/slot?placement='+encodeURIComponent(placement));const ad=result.ad;root.replaceChildren();
    if(!ad){root.hidden=true;return;}
    root.hidden=false;
    const copy=document.createElement('div');copy.className='store-sponsored-ad-copy';
    const label=document.createElement('small');label.textContent=ad.sponsor_name?'Реклама · '+ad.sponsor_name:'Реклама';
    const title=document.createElement('strong');title.textContent=ad.title;
    const body=document.createElement('p');body.textContent=ad.body||'Партнёрское предложение SOLVI.';
    copy.append(label,title,body);
    const button=document.createElement('button');button.type='button';button.className='button button-secondary';button.textContent=ad.cta_label||'Подробнее';
    button.addEventListener('click',()=>{window.open(ad.target_url,'_blank','noopener,noreferrer');api('/api/ads/'+encodeURIComponent(ad.id)+'/click',{method:'POST',body:'{}'}).catch(()=>{});});
    root.append(copy,button);
  }catch{root.hidden=true;}
}
async function loadStoreSponsoredAd(){return loadSponsoredAd('store','#storeSponsoredAd');}
async function loadHomeSponsoredAd(){return loadSponsoredAd('home','#homeSponsoredAd');}
async function loadStore() {
  try { const data = await api('/api/store'); renderStore(data); await loadTokenHistory(); await loadStoreSponsoredAd(); }
  catch (error) { showToast(error.message); }
}
async function loadTokenHistory() {
  try {
    const data = await api('/api/store/transactions');
    const root = $('#tokenHistoryList'); root.replaceChildren();
    if (!data.transactions.length) { const empty = document.createElement('p'); empty.className = 'muted'; empty.textContent = 'История пока пустая.'; root.append(empty); return; }
    data.transactions.forEach(item => {
      const row = document.createElement('div'); row.className = 'token-history-row';
      const copy = document.createElement('span'); copy.textContent = item.description;
      const amount = document.createElement('strong'); amount.className = item.amount < 0 ? 'debit' : 'credit'; amount.textContent = `${item.amount > 0 ? '+' : ''}${item.amount} ✦`;
      const date = document.createElement('time'); date.textContent = new Date(item.created_at).toLocaleDateString('ru-RU');
      row.append(copy, amount, date); root.append(row);
    });
  } catch { /* token history is supplementary */ }
}

async function loadFavorites() {
  try { const data = await api('/api/favorite-chats'); state.favoriteChats = data.chats || []; state.favoriteChatDrafts = data.drafts || []; renderFavorites(); }
  catch (error) { showToast(error.message); }
}
function renderFavorites() {
  const root = $('#favoritesList'); if (!root) return;
  root.replaceChildren();
  if (state.favoriteChatDrafts?.length) {
    const draftHeading = document.createElement('h2'); draftHeading.className = 'favorite-drafts-heading'; draftHeading.textContent = 'Недавно завершённые · готовы к сохранению'; root.append(draftHeading);
    state.favoriteChatDrafts.forEach(draft => {
      const card = document.createElement('article'); card.className = 'favorite-contact-card favorite-chat-card';
      const avatar = document.createElement('div'); avatar.className = 'avatar avatar-medium'; avatar.textContent = draft.partnerAvatar || '◉';
      const details = document.createElement('div'); details.className = 'favorite-card-details';
      const name = document.createElement('strong'); name.textContent = draft.partnerUsername || 'Собеседник';
      const note = document.createElement('p'); note.className = 'favorite-card-note'; note.textContent = `${draft.messageCount || 0} сообщений · доступно до ${new Date(draft.expiresAt).toLocaleDateString('ru-RU')}`;
      details.append(name, note);
      const save = document.createElement('button'); save.type = 'button'; save.className = 'button button-primary'; save.textContent = 'Сохранить';
      save.addEventListener('click', async () => {
        save.disabled = true;
        try { await api('/api/favorite-chats', { method: 'POST', body: JSON.stringify({ matchId: draft.matchId }) }); await loadFavorites(); showToast('Переписка сохранена в Избранное.'); }
        catch (error) { showToast(error.message); save.disabled = false; }
      });
      card.append(avatar, details, save); root.append(card);
    });
  }
  if (!state.favoriteChats.length && !state.favoriteChatDrafts?.length) {
    const empty = document.createElement('div'); empty.className = 'favorites-empty';
    const icon = document.createElement('span'); icon.textContent = '♡';
    const title = document.createElement('strong'); title.textContent = 'Сохранённых разговоров пока нет';
    const copy = document.createElement('p'); copy.textContent = 'Заверши диалог и подтверди сохранение — переписка появится здесь.';
    empty.append(icon, title, copy); root.append(empty); return;
  }
  state.favoriteChats.forEach(chat => {
    const card = document.createElement('article'); card.className = 'favorite-contact-card favorite-chat-card';
    const avatar = document.createElement('div'); avatar.className = 'avatar avatar-medium'; avatar.textContent = chat.partnerAvatar || '◉';
    const details = document.createElement('div'); details.className = 'favorite-card-details';
    const name = document.createElement('strong'); name.textContent = chat.partnerUsername || 'Собеседник';
    const note = document.createElement('p'); note.className = 'favorite-card-note'; note.textContent = `${chat.messageCount || 0} сообщений · ${new Date(chat.createdAt).toLocaleString('ru-RU')}`;
    details.append(name, note);
    const open = document.createElement('button'); open.type = 'button'; open.className = 'button button-primary'; open.textContent = 'Открыть'; open.addEventListener('click', () => openFavoriteChat(chat.id));
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'button button-secondary'; remove.textContent = 'Удалить';
    remove.addEventListener('click', async () => { if (!await appDialog({title:'Удалить переписку?',message:'Эта копия исчезнет из твоего Избранного.',confirmText:'Удалить',danger:true})) return; remove.disabled = true; try { await api(`/api/favorite-chats/${encodeURIComponent(chat.id)}`, { method: 'DELETE' }); state.favoriteChats = state.favoriteChats.filter(row => row.id !== chat.id); renderFavorites(); } catch (error) { showToast(error.message); remove.disabled = false; } });
    card.append(avatar, details, open, remove); root.append(card);
  });
}
async function openFavoriteChat(id) {
  try {
    const data = await api(`/api/favorite-chats/${encodeURIComponent(id)}`);
    state.activeFavoriteChatId = id;
    $('#favoriteChatTitle').textContent = `Диалог с ${data.chat.partnerUsername}`;
    $('#favoriteChatMeta').textContent = new Date(data.chat.createdAt).toLocaleString('ru-RU');
    const root = $('#favoriteChatMessages'); root.replaceChildren();
    (data.messages || []).forEach(message => {
      const row = document.createElement('article'); row.className = `favorite-transcript-message${message.senderId === state.user?.id ? ' mine' : ''}`;
      const head = document.createElement('div'); head.className = 'favorite-transcript-head';
      const sender = document.createElement('strong'); sender.textContent = message.senderId === state.user?.id ? 'Ты' : (message.senderName || 'Собеседник');
      const time = document.createElement('time'); time.textContent = new Date(message.createdAt).toLocaleString('ru-RU'); head.append(sender, time); row.append(head);
      if (message.content) { const body = document.createElement('p'); body.textContent = message.content; row.append(body); }
      if (message.sticker) { const sticker = document.createElement('p'); sticker.className = 'favorite-transcript-sticker'; sticker.textContent = message.sticker; row.append(sticker); }
      (message.attachments || []).forEach(label => { const attachment = document.createElement('small'); attachment.className = 'favorite-transcript-attachment'; attachment.textContent = `[ ${label} — медиа удалено после завершения чата ]`; row.append(attachment); });
      root.append(row);
    });
    if (!root.children.length) { const empty = document.createElement('p'); empty.className = 'muted'; empty.textContent = 'В этой переписке нет сообщений.'; root.append(empty); }
    $('#favoriteChatModal').hidden = false;
  } catch (error) { showToast(error.message); }
}
async function loadGrowthTasks(){
  const root=$('#growthTaskList');if(!root)return;
  try{
    const data=await api('/api/growth');root.replaceChildren();
    if(!(data.tasks||[]).length){const empty=document.createElement('div');empty.className='favorites-empty';empty.textContent='Сейчас нет активных заданий. Загляни позже — здесь появятся бонусы за полезные действия.';root.append(empty);}
    (data.tasks||[]).forEach(task=>{
      const card=document.createElement('article');card.className='growth-task-card';
      const head=document.createElement('div');head.className='growth-task-head';const kicker=document.createElement('span');kicker.className='eyebrow';kicker.textContent=task.sponsor_name?('ПАРТНЁР · '+task.sponsor_name):'ЗАДАНИЕ SOLVI';
      const reward=document.createElement('strong');reward.className='growth-task-reward';reward.textContent='+'+Number(task.reward_tokens)+' ✦';head.append(kicker,reward);
      const title=document.createElement('h3');title.textContent=task.title;const desc=document.createElement('p');desc.textContent=task.description;
      const platform=document.createElement('small');platform.textContent=task.platform;
      const open=document.createElement('a');open.className='button button-secondary';open.href=task.url;open.target='_blank';open.rel='noopener noreferrer';open.textContent='Открыть площадку ↗';
      card.append(head,title,desc,platform,open);
      if(task.submission_status==='pending'){const status=document.createElement('span');status.className='growth-task-status';status.textContent='Заявка на проверке';card.append(status);}
      else if(task.submission_status==='approved'){const status=document.createElement('span');status.className='growth-task-status approved';status.textContent='Награда начислена';card.append(status);}
      else if(task.submission_status==='rejected'){const status=document.createElement('span');status.className='growth-task-status rejected';status.textContent=task.review_note||'Заявка отклонена';card.append(status);}
      else{
        const submit=document.createElement('button');submit.type='button';submit.className='button button-primary';submit.textContent='Я выполнил · отправить доказательство';
        submit.addEventListener('click',async()=>{const proof=await appDialog({title:'Подтверждение выполнения',message:'Вставь HTTPS-ссылку на скриншот или другое доказательство. Токены начислятся после ручной проверки владельцем.',input:true,defaultValue:'https://',confirmText:'Отправить'});if(!proof)return;submit.disabled=true;try{await api('/api/tasks/'+encodeURIComponent(task.id)+'/submit',{method:'POST',body:JSON.stringify({proofUrl:proof})});showToast('Заявка отправлена на проверку.');await loadGrowthTasks();}catch(error){showToast(error.message);submit.disabled=false;}});
        card.append(submit);
      }
      root.append(card);
    });
  }catch(error){showToast(error.message);}
}
const SOCIAL_ICON_MARKUP = {
  telegram: '<path d="M21.6 4.1 18.4 19c-.2 1.1-.9 1.4-1.8.9l-5-3.7-2.4 2.3c-.3.3-.6.6-1.2.6l.4-5.1 9.3-8.4c.4-.4-.1-.6-.6-.2L5.6 12.7.7 11.2c-1.1-.4-1.1-1.2.2-1.7L20 2.1c.9-.3 1.8.2 1.6 2Z"/>',
  youtube: '<path d="M23 7.2a3 3 0 0 0-2.1-2.1C19 4.6 12 4.6 12 4.6s-7 0-8.9.5A3 3 0 0 0 1 7.2 31 31 0 0 0 .5 12a31 31 0 0 0 .5 4.8 3 3 0 0 0 2.1 2.1c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 0 0 2.1-2.1 31 31 0 0 0 .5-4.8 31 31 0 0 0-.5-4.8ZM9.7 15.4V8.6l5.9 3.4-5.9 3.4Z"/>',
  instagram: '<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.6" cy="6.6" r="1.2"/>',
  tiktok: '<path d="M15.5 3h3.1c.2 2 1.3 3.6 3.4 4.3v3.2a9.4 9.4 0 0 1-3.4-1.1v6.7a6.4 6.4 0 1 1-6.4-6.4c.4 0 .8 0 1.2.1v3.3a3.2 3.2 0 1 0 2.1 3V3Z"/>',
  discord: '<path d="M19.7 5.3a18 18 0 0 0-4.4-1.4l-.5 1a16 16 0 0 0-5.6 0l-.5-1a18 18 0 0 0-4.4 1.4C1.5 9.4.8 13.4 1.2 17.4a18 18 0 0 0 5.4 2.7l1.2-2a11 11 0 0 1-1.9-.9l.5-.4a13 13 0 0 0 11.2 0l.5.4a11 11 0 0 1-1.9.9l1.2 2a18 18 0 0 0 5.4-2.7c.5-4.7-.8-8.7-3.1-12.1ZM8.7 14.8c-1 0-1.8-.9-1.8-2s.8-2 1.8-2 1.8.9 1.8 2-.8 2-1.8 2Zm6.6 0c-1 0-1.8-.9-1.8-2s.8-2 1.8-2 1.8.9 1.8 2-.8 2-1.8 2Z"/>',
  vk: '<path d="M3.2 7.2h3.4c.2 4.1 1.9 5.8 3.2 6.2V7.2h3.2v3.5c1.3-.1 2.7-1.7 3.2-3.5h3.2a8.6 8.6 0 0 1-2.9 5.1 8.8 8.8 0 0 1 3.6 5.5h-3.5c-.6-1.8-2.1-3.2-3.6-3.3v3.3h-.4c-5.2 0-8.2-3.6-8.4-10.6Z"/>',
  twitch: '<path d="M4 3h18v12l-5 5h-4l-3 3v-3H5V6l-1  -3Zm3 3v11h5v2l2-2h3l3-3V6H7Zm4 2h2v5h-2V8Zm5 0h2v5h-2V8Z"/>',
  x: '<path d="M18.9 2H22l-6.8 7.8L23.2 22h-6.3l-4.9-7.2L5.7 22H2.5l7.3-8.4L2 2h6.5l4.4 6.6L18.9 2Zm-1.1 18h1.7L7.4 3.9H5.6L17.8 20Z"/>',
  facebook: '<path d="M13.5 22v-8h2.7l.4-3.1h-3.1v-2c0-.9.3-1.5 1.6-1.5h1.7V4.6c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.1H7.3V14h2.8v8h3.4Z"/>',
  default: '<path d="M7 17 17 7M8 7h9v9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
};
function socialPlatformKey(link){
  const value=[link.platform,link.label,link.url].filter(Boolean).join(' ').toLowerCase();
  if(/telegram|t\.me/.test(value))return 'telegram';
  if(/youtube|youtu\.be/.test(value))return 'youtube';
  if(/instagram|instagr\.am/.test(value))return 'instagram';
  if(/tiktok/.test(value))return 'tiktok';
  if(/discord|discord\.gg/.test(value))return 'discord';
  if(/(^|[^a-z])vk([^a-z]|$)|vkontakte/.test(value))return 'vk';
  if(/twitch/.test(value))return 'twitch';
  if(/(^|[^a-z])x([^a-z]|$)|twitter/.test(value))return 'x';
  if(/facebook|fb\.com/.test(value))return 'facebook';
  return 'default';
}
function renderSocialLinks(){
  const root=$('#socialLinksFooter');if(!root)return;root.replaceChildren();
  (state.config?.socialLinks||[]).forEach(link=>{
    const platform=socialPlatformKey(link);
    const a=document.createElement('a');a.className='footer-social-link';a.dataset.platform=platform;
    a.href=link.url;a.target='_blank';a.rel='noopener noreferrer';a.title=link.label;a.setAttribute('aria-label',link.label);
    const icon=document.createElement('span');icon.className='footer-social-icon';
    icon.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">'+(SOCIAL_ICON_MARKUP[platform]||SOCIAL_ICON_MARKUP.default)+'</svg>';
    const label=document.createElement('span');label.className='footer-social-label';label.textContent=link.label;
    a.append(icon,label);root.append(a);
  });
  root.hidden=!root.children.length;
}

async function loadInbox() {
  const root=$('#inboxList');if(!root)return;
  try{
    const data=await api('/api/inbox');state.inboxMessages=data.messages||[];state.inboxUnread=Number(data.unread||0);
    const badge=$('#inboxUnreadBadge');if(badge){badge.hidden=state.inboxUnread<=0;badge.textContent=state.inboxUnread>99?'99+':String(state.inboxUnread);}
    root.replaceChildren();
    if(!state.inboxMessages.length){const empty=document.createElement('div');empty.className='favorites-empty';empty.textContent='Пока нет сообщений от команды SOLVI.';root.append(empty);return;}
    state.inboxMessages.forEach(message=>{
      const card=document.createElement('article');card.className='inbox-message-card'+(message.read_at?'':' unread');
      const head=document.createElement('div');head.className='inbox-message-head';
      const title=document.createElement('strong');title.textContent=message.subject||'Сообщение SOLVI';
      const time=document.createElement('time');time.textContent=new Date(message.created_at).toLocaleString('ru-RU');head.append(title,time);
      const sender=document.createElement('small');sender.textContent='От: '+(message.sender_name||'Команда SOLVI');
      const body=document.createElement('p');body.textContent=message.body;card.append(head,sender,body);
      if(!message.read_at){const button=document.createElement('button');button.type='button';button.className='button button-secondary';button.textContent='Отметить прочитанным';button.addEventListener('click',async()=>{button.disabled=true;try{await api('/api/inbox/'+encodeURIComponent(message.id)+'/read',{method:'POST',body:'{}'});await loadInbox();}catch(error){showToast(error.message);button.disabled=false;}});card.append(button);}
      root.append(card);
    });
  }catch(error){showToast(error.message);}
}

async function loadTickets() {
  try { const data = await api('/api/tickets'); state.tickets = data.tickets || []; renderTicketList(); }
  catch (error) { showToast(error.message); }
}
function renderTicketList() {
  const root = $('#ticketList'); if (!root) return;
  root.replaceChildren();
  if (!state.tickets.length) {
    const empty = document.createElement('div'); empty.className = 'favorites-empty';
    const title = document.createElement('strong'); title.textContent = 'Обращений пока нет';
    const copy = document.createElement('p'); copy.textContent = 'Предложи улучшение или сообщи о проблеме — команда увидит обращение в панели владельца.';
    empty.append(title, copy); root.append(empty); return;
  }
  state.tickets.forEach(ticket => {
    const card = document.createElement('button'); card.type = 'button'; card.className = `ticket-list-card${state.activeTicketId === ticket.id ? ' active' : ''}`;
    const kind = document.createElement('span'); kind.className = 'ticket-kind'; kind.textContent = ticket.category === 'bug' ? 'Ошибка' : 'Идея';
    const title = document.createElement('strong'); title.textContent = ticket.title;
    const status = document.createElement('span'); status.className = `ticket-status ${ticket.status}`; status.textContent = ({open:'Открыт',in_progress:'В работе',closed:'Закрыт'})[ticket.status] || ticket.status;
    const last = document.createElement('small'); last.textContent = ticket.last_message || 'Нет ответов';
    card.append(kind, title, status, last); card.addEventListener('click', () => openTicket(ticket.id)); root.append(card);
  });
}
async function openTicket(id) {
  try {
    const data = await api(`/api/tickets/${encodeURIComponent(id)}`);
    state.activeTicketId = id;
    $('#ticketThreadTitle').textContent = data.ticket.title;
    $('#ticketThreadMeta').textContent = `${data.ticket.category === 'bug' ? 'Сообщение об ошибке' : 'Идея'} · ${({open:'Открыт',in_progress:'В работе',closed:'Закрыт'})[data.ticket.status] || data.ticket.status}`;
    const root = $('#ticketThreadMessages'); root.replaceChildren();
    (data.messages || []).forEach(message => {
      const row = document.createElement('article'); row.className = `ticket-message${message.fromOwner ? ' owner' : ''}`;
      const head = document.createElement('strong'); head.textContent = message.fromOwner ? 'Команда Solvi' : message.senderName;
      const body = document.createElement('p'); body.textContent = message.body;
      const time = document.createElement('time'); time.textContent = new Date(message.createdAt).toLocaleString('ru-RU');
      row.append(head, body, time); root.append(row);
    });
    $('#ticketReplyForm').hidden = data.ticket.status === 'closed';
    $('#ticketCloseButton').hidden = data.ticket.status === 'closed';
    $('#ticketReplyInput').value = '';
    $('#ticketThread').hidden = false;
    renderTicketList(); root.scrollTop = root.scrollHeight;
  } catch (error) { showToast(error.message); }
}

async function loadBlockedUsers() {
  try {
    const data = await api('/api/blocks');
    state.blockedUsers = data.blocked || [];
    renderBlockedUsers();
  } catch (error) { showToast(error.message); }
}
function renderBlockedUsers() {
  const root = $('#blockedList'); if (!root) return;
  root.replaceChildren();
  if (!state.blockedUsers.length) {
    const empty = document.createElement('div'); empty.className = 'favorites-empty';
    const icon = document.createElement('span'); icon.textContent = '✓';
    const title = document.createElement('strong'); title.textContent = 'Список пуст';
    const copy = document.createElement('p'); copy.textContent = 'Здесь появятся люди, которых ты заблокируешь во время общения.';
    empty.append(icon, title, copy); root.append(empty); return;
  }
  state.blockedUsers.forEach(person => {
    const card = document.createElement('article'); card.className = 'favorite-contact-card';
    const avatar = document.createElement('div'); avatar.className = 'avatar avatar-medium'; setAvatarContent(avatar, person);
    const details = document.createElement('div'); details.className = 'favorite-card-details';
    const name = document.createElement('strong'); name.textContent = person.username;
    const description = document.createElement('p'); description.textContent = person.description || 'Пользователь SOLVI';
    details.append(name, description);
    const unblock = document.createElement('button'); unblock.type = 'button'; unblock.className = 'button button-secondary'; unblock.textContent = 'Разблокировать';
    unblock.addEventListener('click', async () => {
      unblock.disabled = true;
      try { await api(`/api/blocks/${encodeURIComponent(person.id)}`, { method: 'DELETE' }); state.blockedUsers = state.blockedUsers.filter(row => row.id !== person.id); renderBlockedUsers(); showToast('Блокировка снята.'); }
      catch (error) { unblock.disabled = false; showToast(error.message); }
    });
    card.append(avatar, details, unblock); root.append(card);
  });
}
async function loadSessions() {
  const root = $('#sessionsList'); if (!root) return;
  const button = $('#loadSessionsButton'); button.disabled = true;
  try {
    const data = await api('/api/sessions');
    root.replaceChildren();
    if (!(data.sessions || []).length) { const empty = document.createElement('p'); empty.className = 'muted'; empty.textContent = 'Активных сессий не найдено.'; root.append(empty); return; }
    data.sessions.forEach(session => {
      const row = document.createElement('div'); row.className = 'session-row';
      const copy = document.createElement('div'); copy.className = 'session-row-copy';
      const title = document.createElement('strong'); title.textContent = session.current ? 'Это устройство' : 'Другое устройство';
      const meta = document.createElement('small'); meta.textContent = `Вход: ${new Date(session.createdAt).toLocaleString('ru-RU')} · До: ${new Date(session.expiresAt).toLocaleString('ru-RU')}`;
      copy.append(title, meta); row.append(copy);
      if (session.current) { const badge = document.createElement('span'); badge.className = 'session-current'; badge.textContent = 'Текущая'; row.append(badge); }
      else {
        const revoke = document.createElement('button'); revoke.type = 'button'; revoke.className = 'button button-secondary'; revoke.textContent = 'Завершить';
        revoke.addEventListener('click', async () => { revoke.disabled = true; try { await api(`/api/sessions/${encodeURIComponent(session.id)}`, { method: 'DELETE' }); showToast('Сессия завершена.'); await loadSessions(); } catch (error) { revoke.disabled = false; showToast(error.message); } });
        row.append(revoke);
      }
      root.append(row);
    });
  } catch (error) { root.replaceChildren(); const line = document.createElement('p'); line.className = 'muted'; line.textContent = error.message; root.append(line); }
  finally { button.disabled = false; }
}

function setAuthError(message = '') { $('#authError').textContent = message; }
function currentView() {
  return ['home', 'search', 'chat', 'profile', 'settings', 'store', 'inventory', 'favorites', 'inbox', 'feedback', 'growth', 'blocked'].find(name => !$(`#${name}Panel`).hidden) || 'home';
}
function setView(view, forceHome = false) {
  if (view === 'home' && state.activeMatch && !forceHome) view = 'chat';
  ['home', 'search', 'chat', 'profile', 'settings', 'store', 'inventory', 'favorites', 'inbox', 'feedback', 'growth', 'blocked'].forEach(name => {
    const panel = $(`#${name}Panel`);
    if (panel) panel.hidden = name !== view;
  });
  const activePanel = $(`#${view}Panel`);
  if (activePanel) {
    activePanel.classList.remove('view-enter');
    requestAnimationFrame(() => activePanel.classList.add('view-enter'));
  }
  $$('[data-view]').forEach(button => button.classList.toggle('active', button.dataset.view === (view === 'search' || view === 'chat' ? 'home' : view)));
  if (view === 'chat') scrollMessages(true);
  if (view === 'home') loadHomeSponsoredAd();
  if (view === 'store') loadStore();
  if (view === 'inventory') loadInventory();
  if (view === 'favorites') loadFavorites();
  if (view === 'inbox') loadInbox();
  if (view === 'feedback') loadTickets();
  if (view === 'growth') loadGrowthTasks();
  if (view === 'blocked') loadBlockedUsers();
}
function setAvatarContent(element, user) {
  if (!element) return;
  element.replaceChildren();
  if (user?.avatarUrl) {
    const image = document.createElement('img'); image.src = user.avatarUrl; image.alt = ''; image.className = 'avatar-image'; image.loading = 'lazy';
    image.addEventListener('error', () => { element.textContent = user.avatar || '◉'; }, { once: true });
    element.append(image);
  } else element.textContent = user?.avatar || '◉';
}

function setUser(user) {
  const isNewAccount = state.user?.id !== user.id;
  state.user = user;
  const messageInput = $('#messageInput');
  if (messageInput) messageInput.maxLength = user.subscriptionTier === 'premium' ? 5000 : (user.subscriptionTier === 'vip' ? 3000 : 2000);
  document.documentElement.dataset.role = user.role === 'owner' ? 'owner' : (user.role || 'member');
  document.documentElement.dataset.memberTier = ['vip', 'premium'].includes(user.subscriptionTier) ? user.subscriptionTier : 'free';
  const messageLimit = user.subscriptionTier === 'premium' ? 5000 : (user.subscriptionTier === 'vip' ? 3000 : 2000);
  if (messageInput) messageInput.maxLength = messageLimit;
  $('#messageHint').textContent = `До ${messageLimit.toLocaleString('ru-RU')} символов · Enter — отправить · Shift + Enter — новая строка`;
  if ($('#languageOptions')) renderFilters();
  if (isNewAccount) state.selectedAvatar = user.avatarUrl ? null : user.avatar;
  setAvatarContent($('#sideAvatar'), user);
  setAvatarContent($('#topAvatar'), user);
  $('#sideUsername').textContent = user.username;
  $('#topUsername').textContent = user.username;
  $('#sidePublicId').textContent = `ID: ${user.publicId} ⧉`;
  setAvatarContent($('#profilePreviewAvatar'), user);
  $('#profilePreviewName').textContent = user.username;
  $('#profilePreviewId').textContent = `Технический ID: ${user.publicId}`;
  const stats = user.stats || { chats: 0, activeMinutes: 0, messages: 0 };
  $('#profileStats').innerHTML = `<div><strong>${Number(stats.chats || 0).toLocaleString('ru-RU')}</strong><span>диалогов</span></div><div><strong>${Number(stats.activeMinutes || 0).toLocaleString('ru-RU')}</strong><span>минут общения</span></div><div><strong>${Number(stats.messages || 0).toLocaleString('ru-RU')}</strong><span>сообщений</span></div>`;
  $('#profileRoleBadge').textContent = user.badge || 'Участник';
  $('#profileMembershipLine').textContent = user.subscriptionTier === 'free' ? 'Стандартный участник' : `${user.subscriptionTier.toUpperCase()} до ${user.subscriptionExpiresAt ? new Date(user.subscriptionExpiresAt).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—'}`;
  $('#profileTokenBalance').textContent = Number(user.tokens || 0).toLocaleString('ru-RU');
  $('#profileCreatedAt').textContent = `В SOLVI с ${new Date(user.createdAt).toLocaleDateString('ru-RU')}`;
  $('#profileUsername').value = user.username;
  state.ownGender = ['male', 'female'].includes(user.gender) ? user.gender : '';
  renderGenderChoices();
  const isGuest = user.accountType === 'guest';
  $('#profileUsername').disabled = isGuest;
  $('#profileUsernameLabel').hidden = isGuest;
  $('#profileUsername').hidden = isGuest;
  $('#saveProfileButton').hidden = isGuest;
  $('#avatarOptions').hidden = false;
  $('#avatarUploadButton').hidden = false;
  state.settings = { ...state.settings, ...(user.settings || {}) };
  applyEquipped(user.equipped || {});
  $('#accountTypeBadge').textContent = isGuest ? 'ГОСТЬ' : 'АККАУНТ';
  $('#profileAccountType').textContent = isGuest ? 'ГОСТЕВОЙ ПРОФИЛЬ · 3 ДНЯ' : 'ПОСТОЯННЫЙ АККАУНТ';
  $('#guestClaimCard').hidden = !isGuest;
  const guestExpiry = user.guestExpiresAt ? new Date(user.guestExpiresAt) : null;
  if ($('#guestExpiryNote')) $('#guestExpiryNote').textContent = isGuest
    ? `Гостевой профиль действует до ${guestExpiry && !Number.isNaN(guestExpiry.getTime()) ? guestExpiry.toLocaleString('ru-RU', { day: '2-digit', month: 'long', hour: '2-digit', minute: '2-digit' }) : 'истечения срока'}. Ник и пароль изменить нельзя. Аватар можно менять.`
    : '';
  $('#sidePublicId').hidden = false;
  renderSettingsControls();
  applySettings();
  renderAvatarOptions();
  renderStickerPanel();
  try { if (state.token) safeStorageSet('sovli_user_cache', JSON.stringify(user)); } catch { /* cached profile is optional */ }
}
async function api(url, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  const response = await fetch(url, { ...options, headers });
  let payload = {};
  try { payload = await response.json(); } catch { /* non-JSON response */ }
  if (!response.ok) {
    const error = new Error(payload.error || `Ошибка запроса (${response.status})`);
    error.status = response.status;
    // Only boot() may invalidate a session after /api/me confirms it.
    // A 401 from an unrelated background endpoint must not erase the user's token.
    throw error;
  }
  return payload;
}
function showAuth() {
  document.documentElement.classList.remove('session-checking');
  const bootScreen = $('#sessionBootScreen');
  if (bootScreen) bootScreen.hidden = true;
  $('#authView').hidden = false;
  $('#appView').hidden = true;
}
function showApp() {
  document.documentElement.classList.remove('session-checking');
  const bootScreen = $('#sessionBootScreen');
  if (bootScreen) bootScreen.hidden = true;
  $('#authView').hidden = true;
  $('#appView').hidden = false;
  setView('home');
  if (state.token) loadInbox().catch(() => {});
}
function switchAuthMode(mode) {
  state.authMode = mode;
  const isRegister = mode === 'register';
  $('#authTitle').textContent = isRegister ? 'Создай свой аккаунт' : 'С возвращением';
  $('#authSubtitle').textContent = isRegister
    ? 'Придумай уникальный ник и пароль. Никакой лишней анкеты.'
    : 'Войди, используя свой никнейм и пароль.';
  $('#authUsernameLabel').textContent = 'Никнейм';
  $('#authUsername').placeholder = isRegister ? 'Придумай никнейм' : 'Твой никнейм';
  $('#authSubmit').querySelector('span:first-child').textContent = isRegister ? 'Создать аккаунт' : 'Войти в SOLVI';
  $('#authPassword').autocomplete = isRegister ? 'new-password' : 'current-password';
  $('#authPassword').placeholder = 'Не менее 8 символов';
  $$('[data-auth-tab]').forEach(button => button.classList.toggle('active', button.dataset.authTab === mode));
  setAuthError('');
}
function renderChoices(container, values, selected, onToggle) {
  container.replaceChildren();
  values.forEach(value => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `choice-chip${selected.includes(value) ? ' selected' : ''}`;
    button.textContent = value;
    button.setAttribute('aria-pressed', String(selected.includes(value)));
    button.addEventListener('click', () => onToggle(value));
    container.append(button);
  });
}
function toggleChoice(listName, value, container, values, limit) {
  const list = state[listName];
  if (list.includes(value)) state[listName] = list.filter(item => item !== value);
  else if (list.length >= limit) { showToast(`Можно выбрать не больше ${limit}.`); return; }
  else state[listName] = [...list, value];
  renderFilters();
}
function renderGenderChoices() {
  const selectedValues = {
    own: state.ownGender || '',
    desired: state.desiredGender || 'any'
  };
  document.querySelectorAll('[data-gender-target][data-gender]').forEach(button => {
    const target = button.dataset.genderTarget;
    const selected = button.dataset.gender === selectedValues[target];
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
}

function renderFilters() {
  const tier = state.user?.subscriptionTier || 'free';
  const languageLimit = tier === 'premium' ? 10 : (tier === 'vip' ? 5 : 3);
  const languages = Array.isArray(state.config.languages) ? state.config.languages : [];
  state.selectedLanguages = (Array.isArray(state.selectedLanguages) ? state.selectedLanguages : [])
    .filter(value => languages.includes(value)).slice(0, languageLimit);
  renderGenderChoices();
  if ($('#standardInterestBlock')) $('#standardInterestBlock').hidden = true;
  if ($('#languageOptions')) renderChoices($('#languageOptions'), languages, state.selectedLanguages, value => toggleChoice('selectedLanguages', value, $('#languageOptions'), languages, languageLimit));
  if ($('#languageSummary')) $('#languageSummary').textContent = state.selectedLanguages.length ? state.selectedLanguages.join(', ') : 'Любой язык';
  if ($('#languageCount')) $('#languageCount').textContent = state.selectedLanguages.length ? `${state.selectedLanguages.length} / ${languageLimit}` : 'Не ограничивать';
  try {
    safeStorageSet('sovli_languages', JSON.stringify(state.selectedLanguages));
    safeStorageSet('solvi_desired_gender', state.desiredGender || 'any');
  } catch { /* filter preferences are optional */ }
}

function buildMatchingPreferences() {
  const interests = state.selectedInterests;
  return {
    mode: 'chat',
    ownGender: state.ownGender,
    desiredGender: state.desiredGender,
    languages: state.selectedLanguages,
    interests
  };
}
function validateMatchingPreferences() {
  if (!['male', 'female'].includes(state.ownGender)) {
    showToast('Сначала выбери свой пол в форме поиска — он нужен для взаимного подбора.');
    $('#ownGenderChoices button')?.focus();
    return false;
  }
  return true;
}

function renderAvatarOptions() {
  if (!state.user) return;
  if (!state.selectedAvatar && !state.user.avatarUrl) state.selectedAvatar = state.user.avatar;
  const container = $('#avatarOptions');
  container.replaceChildren();
  const avatarChoices = Array.isArray(state.config.avatars) && state.config.avatars.length ? state.config.avatars : DEFAULT_AVATARS;
  avatarChoices.forEach(avatar => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `avatar-option${state.selectedAvatar === avatar ? ' selected' : ''}`;
    button.textContent = avatar;
    button.setAttribute('aria-label', `Выбрать аватар ${avatar}`);
    button.setAttribute('aria-pressed', String(state.selectedAvatar === avatar));
    button.addEventListener('click', async () => {
      state.selectedAvatar = avatar;
      renderAvatarOptions();
      setAvatarContent($('#profilePreviewAvatar'), { ...state.user, avatar, avatarUrl: null });
      if (state.user.accountType === 'guest') {
        button.disabled = true;
        try { const result = await api('/api/profile', { method: 'PATCH', body: JSON.stringify({ username: state.user.username, avatar }) }); setUser(result.user); showToast('Аватар обновлён.'); }
        catch (error) { showToast(error.message); }
        finally { button.disabled = false; }
      }
    });
    container.append(button);
  });
}
function connectSocket() {
  if (state.socket) state.socket.disconnect();
  state.socket = io({ auth: { token: state.token, lastMatchId: state.activeMatch?.matchId || null }, reconnection: true, reconnectionAttempts: Infinity, reconnectionDelay: 700, reconnectionDelayMax: 5000, timeout: 10000 });
  const socket = state.socket;
  socket.on('connect', () => {
    if (state.searching) {
      socket.emit('queue:join', buildMatchingPreferences(), result => {
        if (!result?.ok) { state.searching = false; clearSearchTimer(); setView('home'); showToast(result?.error || 'Не удалось возобновить поиск.'); }
      });
    }
    if (state.activeMatch) { markRead(); flushOutbox(); }
  });
  socket.on('connect_error', error => {
    if (error.message?.includes('авторизац') || error.message?.includes('Сессия') || error.message?.includes('гостевого')) {
      showToast('Сессия завершена. Войдите снова.');
      logout(false);
    } else if (state.searching) {
      $('#searchStatusText').textContent = 'Связь прервалась. Пытаемся подключиться снова…';
    }
  });
  socket.on('disconnect', () => {
    state.readPending = false;
    if (state.searching) $('#searchStatusText').textContent = 'Связь прервалась. Восстанавливаем подключение…';
    if (state.activeMatch) $('#partnerStateText').textContent = 'Переподключение…';
  });
  socket.on('presence:count', data => { $('#onlineCount').textContent = String(data.count ?? 0); });
  socket.on('wallet:updated', data => { if (state.user) state.user.tokens = Number(data.balance || 0); const balance = $('#storeBalance'); if (balance) balance.textContent = Number(data.balance || 0).toLocaleString('ru-RU'); const profileBalance = $('#profileTokenBalance'); if (profileBalance) profileBalance.textContent = Number(data.balance || 0).toLocaleString('ru-RU'); if (data.earned && data.reason !== 'ai_chat_reward') showToast(`+${data.earned} токен(ов) за активное общение ✦`, 2200); });
  socket.on('moderation:notice', payload => {
    const message = String(payload?.message || '').trim();
    if (message) showToast(`Сообщение от команды SOLVI: ${message}`, 7500);
  });
  socket.on('site:message', payload => {
    const subject=String(payload?.subject||'Сообщение от SOLVI').trim(),body=String(payload?.body||'').trim();
    if(body)showToast(subject+': '+body,8000);
    if(currentView()==='inbox')loadInbox().catch(()=>{});
    if(document.visibilityState==='hidden'&&state.settings.browserNotifications&&'Notification' in window&&Notification.permission==='granted')new Notification(subject,{body:body.slice(0,160),icon:'/favicon.svg',tag:payload?.id||'solvi-site-message'});
  });
  socket.on('queue:waiting', () => {
    if (state.searching) $('#searchStatusText').textContent = 'Подбираем собеседника на русском языке.';
  });
  socket.on('queue:aiUnavailable', data => {
    if (!state.searching) return;
    $('#searchStatusText').textContent = data?.reason === 'api_key'
      ? 'Людей пока не нашли. ИИ-подбор включится после настройки Gemini API.'
      : 'Продолжаем искать человека.';
  });
  socket.on('queue:cancelled', () => { state.searching = false; clearSearchTimer(); setView('home'); });
  socket.on('match:found', match => activateMatch(match));
  socket.on('chat:restored', payload => {
    state.activeMatch = { matchId: payload.matchId, isAi: Boolean(payload.isAi || payload.partner?.isAi), partner: payload.partner, commonInterests: payload.commonInterests || [], startedAt: payload.startedAt };
    state.messages = payload.messages || [];
    restoreOutbox();
    restoreDraft();
    renderChatHeader();
    renderMessages();
    setView('chat');
    markRead();
    flushOutbox();
    showToast('Соединение восстановлено.');
  });
  socket.on('chat:message', message => {
    if (!state.activeMatch || message.match_id !== state.activeMatch.matchId) return;
    mergeMessage(message);
    if (message.sender_id !== state.user.id) {
      playUiSound(740);
      if (document.visibilityState === 'visible') markRead();
      else if (state.settings.browserNotifications && 'Notification' in window && Notification.permission === 'granted') new Notification(state.activeMatch?.partner?.username || 'Новое сообщение', { body: (message.content || (message.type === 'voice' ? 'Голосовое сообщение' : 'Вложение')).slice(0, 120), icon: '/favicon.svg', tag: state.activeMatch?.matchId });
    }
  });
  socket.on('ai:message', message => {
    if (!state.activeMatch?.isAi || message.match_id !== state.activeMatch.matchId) return;
    mergeMessage(message);
    playUiSound(740);
  });
  socket.on('ai:reward', data => {
    showToast(data.message || 'Награда от ИИ-собеседника!', 5200);
    if (data.itemId && currentView() === 'inventory') loadInventory();
    if (data.itemId && currentView() === 'store') loadStore();
  });
  socket.on('chat:status', data => {
    const item = state.messages.find(message => message.id === data.messageId);
    if (item) { item.delivered_at = data.at; renderMessages(); }
  });
  socket.on('chat:read-receipt', data => {
    const ids = new Set(data.messageIds || []);
    state.messages.forEach(message => { if (ids.has(message.id)) { message.read_at = data.readAt; message.delivered_at ||= data.readAt; } });
    renderMessages();
  });
  socket.on('chat:reactions', data => {
    const message = state.messages.find(item => item.id === data.messageId);
    if (message) { message.reactions = data.reactions || []; renderMessages(); }
  });
  socket.on('chat:typing', data => {
    if (data.userId !== state.activeMatch?.partner?.id) return;
    $('#typingIndicator').hidden = !data.typing;
    clearTimeout(state.partnerTypingTimer);
    // AI typing lasts for its full simulated WPM interval; human typing keeps the safety timeout.
    if (data.typing && !data.isAi) state.partnerTypingTimer = setTimeout(() => { $('#typingIndicator').hidden = true; }, 2200);
  });
  socket.on('chat:recording', data => {
    if (data.userId === state.activeMatch?.partner?.id) $('#recordingIndicator').hidden = !data.recording;
  });
  socket.on('ticket:updated', () => { if (!$('#feedbackPanel')?.hidden) { loadTickets(); if (state.activeTicketId) openTicket(state.activeTicketId); } });
  socket.on('chat:ended', async data => {
    if (state.activeMatch?.matchId !== data.matchId) return;
    state.activeMatch = null;
    state.messages = [];
    releaseMediaUrls();
    state.outbox = [];
    persistOutbox();
    try { if (draftKey()) safeStorageRemove(draftKey()); } catch { /* ignore */ }
    $('#typingIndicator').hidden = true;
    $('#recordingIndicator').hidden = true;
    stopVoiceRecording(true);
    if (!state.searching) setView('home');
    if (data.reason !== 'user_next') showToast(endReasonText(data.reason));
    if (data.canFavorite && await appDialog({title:'Сохранить переписку?',message:'Текст и стикеры останутся в Избранном. Фото и голосовые удаляются вместе с чатом.',confirmText:'Сохранить'})) {
      try { await api('/api/favorite-chats', { method: 'POST', body: JSON.stringify({ matchId: data.matchId }) }); await loadFavorites(); showToast('Переписка сохранена в Избранное.'); }
      catch (error) { showToast(error.message); }
    }
  });
  socket.on('auth:expired', () => {
    logout(false, false);
    setAuthError('Срок гостевого доступа завершился. Создай новый гостевой профиль или войди в постоянный аккаунт.');
  });
  socket.on('account:deleted', () => logout(false, false));
}
function endReasonText(reason) {
  const messages = {
    user_ended: 'Диалог завершён. Теперь можно сохранить его в Избранное.',
    user_next: 'Ищем следующего собеседника…',
    reported: 'Жалоба отправлена. Диалог завершён.',
    blocked: 'Пользователь заблокирован.',
    connection_lost: 'Соединение потеряно. Диалог завершён.',
    server_restart: 'Сервер перезапустился. Диалог завершён.',
    account_deleted: 'Аккаунт удалён.',
    guest_expired: 'Гостевой доступ завершился.'
  };
  return messages[reason] || 'Диалог завершён.';
}
function activateMatch(match) {
  state.searching = false;
  clearSearchTimer();
  releaseMediaUrls();
  state.activeMatch = match;
  state.messages = [];
  state.favorites = [];
  state.tokenHistoryLoaded = false;
  state.replyTarget = null;
  if ($('#replyPreview')) { $('#replyPreview').hidden = true; $('#replyPreview').querySelector('span').textContent = ''; }
  state.outbox = [];
  persistOutbox();
  $('#typingIndicator').hidden = true;
  $('#recordingIndicator').hidden = true;
  restoreDraft();
  renderChatHeader();
  renderMessages();
  setView('chat');
  showToast(match.isAi ? 'Это ИИ-персонаж SOLVI. Сообщения обрабатывает Gemini — не отправляй личные данные.' : 'Собеседник найден. Хорошего разговора!', match.isAi ? 6500 : 2800);
}
function renderChatHeader() {
  const partner = state.activeMatch?.partner;
  if (!partner) return;
  setAvatarContent($('#partnerAvatar'), partner);
  $('#partnerName').textContent = partner.username || 'Собеседник';
  $('#partnerStateText').textContent = partner.isAi ? 'ИИ-собеседник · бот-персонаж' : ([partner.badge, partner.cosmeticTitle].filter(Boolean).join(' · ') || 'На связи');
  $('#partnerName').title = partner.description || partner.username || '';
  const common = state.activeMatch.commonInterests || [];
  const container = $('#commonInterests');
  container.replaceChildren();
  if (common.length) {
    const label = document.createElement('span');
    label.textContent = 'Общее';
    container.append(label);
    common.forEach(interest => {
      const chip = document.createElement('span');
      chip.textContent = interest;
      container.append(chip);
    });
    container.hidden = false;
  } else container.hidden = true;
}
function formatTime(value) {
  const date = new Date(value || Date.now());
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}
function messageStatus(message) {
  if (message.status === 'sending') return 'Отправка…';
  if (message.status === 'failed') return 'Ошибка отправки';
  if (message.read_at) return 'Прочитано';
  if (message.delivered_at) return 'Доставлено';
  return 'Отправлено';
}
function releaseMediaUrls() {
  for (const url of state.mediaUrls.values()) URL.revokeObjectURL(url);
  state.mediaUrls.clear();
  state.mediaLoading.clear();
}
async function loadMediaElement(element, attachment) {
  if (!attachment?.id || !state.token) return;
  const existing = state.mediaUrls.get(attachment.id);
  if (existing) { element.src = existing; return; }
  if (state.mediaLoading.has(attachment.id)) {
    const wait = setInterval(() => {
      const url = state.mediaUrls.get(attachment.id);
      if (url || !state.mediaLoading.has(attachment.id)) {
        clearInterval(wait);
        if (url && element.isConnected) element.src = url;
      }
    }, 150);
    return;
  }
  state.mediaLoading.add(attachment.id);
  try {
    const response = await fetch(attachment.url, { headers: { Authorization: `Bearer ${state.token}` } });
    if (!response.ok) throw new Error('media unavailable');
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    state.mediaUrls.set(attachment.id, url);
    if (element.isConnected) element.src = url;
  } catch {
    element.dataset.failed = 'true';
    if (element.tagName === 'IMG') element.alt = 'Фото больше недоступно';
  } finally { state.mediaLoading.delete(attachment.id); }
}
function reactToMessage(messageId, emoji) {
  if (!state.socket?.connected || !state.activeMatch || String(messageId).startsWith('pending:')) return;
  state.socket.emit('chat:react', { matchId: state.activeMatch.matchId, messageId, emoji }, result => {
    if (!result?.ok) showToast(result?.error || 'Не удалось поставить реакцию.');
    else {
      const message = state.messages.find(item => item.id === messageId);
      if (message) { message.reactions = result.reactions || []; renderMessages(); }
    }
  });
}
function renderMessages() {
  const container = $('#messages');
  const stickToBottom = state.forceScrollToBottom || (container.scrollHeight - container.scrollTop - container.clientHeight < 150);
  state.forceScrollToBottom = false;
  container.replaceChildren();
  if (!state.messages.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-chat';
    const symbol = document.createElement('div');
    symbol.className = 'empty-chat-icon';
    symbol.textContent = '✳';
    const text = document.createElement('div');
    text.textContent = 'Неловко начинать? Вот несколько вариантов:';
    const prompts = document.createElement('div');
    prompts.className = 'icebreaker-list';
    ['Привет! Как проходит твой день?', 'Что сейчас слушаешь?', 'Посоветуй фильм или сериал'].forEach(prompt => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'icebreaker-chip';
      button.textContent = prompt;
      button.addEventListener('click', () => sendMessage(prompt, crypto.randomUUID()));
      prompts.append(button);
    });
    empty.append(symbol, text, prompts);
    container.append(empty);
    return;
  }
  state.messages.forEach(message => {
    const mine = message.sender_id === state.user.id;
    const row = document.createElement('div');
    row.id = `message-${String(message.id).replace(/[^a-zA-Z0-9_-]/g, '')}`;
    row.className = `message-row${mine ? ' mine' : ''}${message.status === 'failed' ? ' failed' : ''}${message.isTypingDraft ? ' ai-streaming' : ''}`;
    const bubble = document.createElement('div');
    bubble.className = `message-bubble${message.type === 'sticker' ? ' sticker-bubble' : ''}`;
    if (message.type === 'sticker') {
      const sticker = document.createElement('span');
      sticker.className = 'message-sticker';
      sticker.textContent = message.sticker || '✨';
      bubble.append(sticker);
    }
    if (message.replyTo) {
      const quote = document.createElement('button'); quote.type = 'button'; quote.className = 'message-reply-quote';
      quote.textContent = `↪ ${message.replyTo.senderId === state.user.id ? 'Твой ответ' : (state.activeMatch?.partner?.username || 'Собеседник')}: ${(message.replyTo.content || 'Вложение').slice(0, 100)}`;
      quote.title = 'Перейти к исходному сообщению';
      quote.addEventListener('click', () => {
        const targetId = `message-${String(message.replyTo.id).replace(/[^a-zA-Z0-9_-]/g, '')}`;
        const target = document.getElementById(targetId);
        if (!target) { showToast('Исходное сообщение уже недоступно.'); return; }
        target.scrollIntoView({ behavior: state.settings.reducedMotion ? 'auto' : 'smooth', block: 'center' });
        target.classList.add('reply-highlight');
        setTimeout(() => target.classList.remove('reply-highlight'), 1500);
      });
      bubble.append(quote);
    }
    if (message.content || message.isTypingDraft) {
      const text = document.createElement('div');
      text.className = 'message-text';
      text.textContent = message.content;
      bubble.append(text);
    }
    (message.attachments || []).forEach(attachment => {
      if (attachment.kind === 'image') {
        if (!attachment.url) { const pending = document.createElement('div'); pending.className = 'media-pending'; pending.textContent = '▧ Фото подготовлено к отправке…'; bubble.append(pending); return; }
        const image = document.createElement('img');
        image.className = 'message-image';
        image.alt = 'Изображение в сообщении';
        image.loading = 'lazy';
        image.addEventListener('click', () => { const url = state.mediaUrls.get(attachment.id); if (url) window.open(url, '_blank', 'noopener,noreferrer'); });
        loadMediaElement(image, attachment);
        bubble.append(image);
      } else if (attachment.kind === 'audio') {
        if (!attachment.url) { const pending = document.createElement('div'); pending.className = 'media-pending'; pending.textContent = '◉ Голосовое подготовлено к отправке…'; bubble.append(pending); return; }
        const audioWrap = document.createElement('div');
        audioWrap.className = 'message-audio-wrap';
        const audio = document.createElement('audio');
        audio.className = 'message-audio';
        audio.controls = true;
        audio.preload = 'none';
        const speed = document.createElement('button');
        speed.type = 'button';
        speed.className = 'audio-speed';
        speed.textContent = '1×';
        speed.title = 'Скорость воспроизведения';
        const speeds = [1, 1.5, 2];
        let speedIndex = 0;
        speed.addEventListener('click', () => {
          speedIndex = (speedIndex + 1) % speeds.length;
          audio.playbackRate = speeds[speedIndex];
          speed.textContent = `${speeds[speedIndex]}×`;
        });
        loadMediaElement(audio, attachment);
        audioWrap.append(audio, speed);
        bubble.append(audioWrap);
      }
    });
    const meta = document.createElement('div');
    meta.className = 'message-meta';
    const time = document.createElement('span');
    time.textContent = formatTime(message.created_at);
    meta.append(time);
    if (mine) {
      const status = document.createElement('span');
      status.className = 'message-status';
      status.textContent = messageStatus(message);
      meta.append(status);
      if (message.status === 'failed') {
        const retry = document.createElement('button');
        retry.type = 'button';
        retry.className = 'retry-button';
        retry.textContent = 'Повторить';
        retry.addEventListener('click', () => retryMessage(message));
        meta.append(retry);
      }
    }
    row.append(bubble, meta);
    const reactions = document.createElement('div');
    reactions.className = 'message-reactions';
    (message.reactions || []).forEach(reaction => {
      const pill = document.createElement(mine ? 'span' : 'button');
      if (!mine) { pill.type = 'button'; pill.addEventListener('click', () => reactToMessage(message.id, reaction.emoji)); }
      pill.className = `reaction-pill${reaction.mine ? ' mine' : ''}`;
      pill.textContent = `${reaction.emoji}${Number(reaction.count) > 1 ? ` ${reaction.count}` : ''}`;
      reactions.append(pill);
    });
    if (!String(message.id).startsWith('pending:') && !mine && !message.isTypingDraft) {
      ['❤️', '😂', '🔥', '👏'].forEach(emoji => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'reaction-add';
        button.textContent = emoji;
        button.title = `Поставить реакцию ${emoji}`;
        button.addEventListener('click', () => reactToMessage(message.id, emoji));
        reactions.append(button);
      });
    }
    if (!String(message.id).startsWith('pending:') && !mine && !message.isTypingDraft) {
      const reply = document.createElement('button'); reply.type = 'button'; reply.className = 'message-reply-button'; reply.textContent = '↩ Ответить';
      reply.addEventListener('click', () => {
        state.replyTarget = message;
        const preview = $('#replyPreview');
        if (preview) { preview.hidden = false; preview.querySelector('span').textContent = `Ответ на ${mine ? 'твоё сообщение' : (state.activeMatch?.partner?.username || 'собеседника')}: ${(message.content || (message.type === 'voice' ? 'Голосовое сообщение' : 'Вложение')).slice(0, 90)}`; }
        $('#messageInput').focus();
      });
      reactions.append(reply);
    }
    if (reactions.children.length) row.append(reactions);
    container.append(row);
  });
  if (stickToBottom) scrollMessages(true);
}
function scrollMessages(force = false) {
  const container = $('#messages');
  if (container && force) container.scrollTop = container.scrollHeight;
}
function mergeMessage(incoming) {
  const index = state.messages.findIndex(message => message.id === incoming.id || (message.client_id && message.client_id === incoming.client_id && message.sender_id === incoming.sender_id));
  if (index >= 0) state.messages[index] = { ...state.messages[index], ...incoming, status: undefined };
  else state.messages.push(incoming);
  state.messages.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  renderMessages();
}
function markRead() {
  if (!state.socket?.connected || !state.activeMatch || state.readPending || document.visibilityState !== 'visible' || $('#chatPanel')?.hidden) return;
  state.readPending = true;
  state.socket.emit('chat:read', { matchId: state.activeMatch.matchId }, () => { state.readPending = false; });
}
function startSearch() {
  if (state.config.matchingEnabled === false) { showToast('Публичный подбор пока отключён до завершения проверки безопасности.'); return; }
  if (!state.socket?.connected) { showToast('Подключаемся к серверу. Попробуй ещё раз через секунду.'); return; }
  if (state.activeMatch) { setView('chat'); return; }
  if (!validateMatchingPreferences()) return;
  state.searching = true;
  state.searchStartedAt = Date.now();
  $('#expandSearchButton').hidden = true;
  $('#searchStatusTitle').textContent = 'Ищем собеседника';
  $('#searchStatusText').textContent = 'Подбираем человека с похожими интересами.';
  $('#mascotMessage').textContent = 'Сосис-Мышь уже побежала искать тебе человека.';
  $('#mascotStage').classList.add('mascot-active');
  $('#mascotSpeech').textContent = 'ПИ-ПИ! ИЩУ ЛЮДЕЙ!';
  $('#searchWaitingHint').textContent = state.selectedLanguages.length ? 'Ищем человека, с которым у вас есть общий язык.' : 'Языковых ограничений нет — ищем любого подходящего собеседника.';
  setView('search');
  updateSearchTimer();
  state.searchInterval = setInterval(updateSearchTimer, 1000);
  state.socket.emit('queue:join', buildMatchingPreferences(), result => {
    if (!result?.ok) {
      state.searching = false;
      clearSearchTimer();
      setView('home');
      showToast(result?.error || 'Не удалось начать поиск.');
    }
  });
}
function updateSearchTimer() {
  if (!state.searching) return;
  const seconds = Math.floor((Date.now() - state.searchStartedAt) / 1000);
  $('#searchTimer').textContent = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  const mascotLines = ['Мышь-сосиска побежала. Сосиска-мышь покатилась.', 'Проверяю сыр. Собеседник тоже где-то рядом.', 'Это не паника. Это сосисочная аэродинамика.', 'Пи-пи. Простите, профессиональная деформация.', 'Хвост запутался в Wi-Fi, сейчас распутаю.', 'Я маленькая, но коммуникабельная.'];
  const mascotSpeech = ['ГДЕ МОЙ СЫР?!', 'СОСИСКА НА СВЯЗИ!', 'ПИ-ПИ, НЕ МЕШАЙ!', 'ХВОСТ НЕ ПОДВЕДИ!'];
  if (seconds % 7 === 0) { $('#mascotMessage').textContent = mascotLines[Math.floor(seconds / 7) % mascotLines.length]; $('#mascotSpeech').textContent = mascotSpeech[Math.floor(seconds / 7) % mascotSpeech.length]; }
  $('#mascotStage').dataset.mood = seconds > 35 ? 'chaos' : (seconds > 15 ? 'impatient' : 'hopeful');
  if (seconds >= 20) $('#searchWaitingHint').textContent = 'Пока ищем — можно подождать или снять часть фильтров.';
  if (seconds >= 30 && (state.selectedLanguages.length || state.selectedInterests.length)) $('#expandSearchButton').hidden = false;
  if (seconds >= 45) $('#searchStatusText').textContent = 'Подходящий собеседник пока не найден. Поиск продолжается.';
}
function nextPartner() {
  if (!state.activeMatch) { startSearch(); return; }
  if (!state.socket?.connected) { showToast('Нет соединения. Подключаемся…'); return; }
  if (!validateMatchingPreferences()) return;
  const matchId = state.activeMatch.matchId;
  state.searching = true;
  state.searchStartedAt = Date.now();
  $('#expandSearchButton').hidden = true;
  $('#searchStatusTitle').textContent = 'Ищем следующего';
  $('#searchStatusText').textContent = 'Закрываем предыдущий разговор и ищем новую встречу.';
  $('#mascotMessage').textContent = 'Следующий! Сосис-Мышь ушла в занос.';
  $('#mascotStage').classList.add('mascot-active');
  $('#mascotSpeech').textContent = 'ХВОСТ ВПЕРЁД!';
  setView('search');
  updateSearchTimer();
  state.searchInterval = setInterval(updateSearchTimer, 1000);
  state.socket.emit('chat:next', { matchId, preferences: buildMatchingPreferences() }, result => {
    if (!result?.ok) {
      state.searching = false;
      clearSearchTimer();
      setView('home');
      showToast(result?.error || 'Не удалось начать следующий поиск.');
    }
  });
}

function clearSearchTimer() {
  if (state.searchInterval) clearInterval(state.searchInterval);
  state.searchInterval = null;
}
function cancelSearch() {
  if (state.socket?.connected) state.socket.emit('queue:cancel');
  $('#expandSearchButton').hidden = true;
  state.searching = false;
  $('#mascotStage').classList.remove('mascot-active');
  clearSearchTimer();
  setView('home');
}
function sendMessage(content, clientId, extras = {}) {
  if (!state.activeMatch) { showToast('Сначала найди собеседника.'); return; }
  const attachments = Array.isArray(extras.attachments) ? extras.attachments : [];
  const sticker = typeof extras.sticker === 'string' ? extras.sticker : null;
  if (state.activeMatch.isAi && attachments.length) { showToast('ИИ-собеседник пока поддерживает текст и стикеры, но не фото и голосовые.'); return; }
  const replyToId = extras.replyToId || state.replyTarget?.id || null;
  if (replyToId && state.replyTarget?.sender_id === state.user?.id) {
    showToast('Нельзя отвечать на собственное сообщение.');
    return;
  }
  if (!content && !attachments.length && !sticker) return;
  const message = {
    id: `pending:${clientId}`, match_id: state.activeMatch.matchId,
    sender_id: state.user.id, client_id: clientId, content, replyTo: replyToId ? { id: replyToId, content: state.replyTarget?.content || '' } : null, attachments: attachments.map(id => ({ id, kind: extras.kind || 'image', url: '' })), sticker, type: sticker ? 'sticker' : (attachments.length ? (extras.kind === 'audio' ? 'voice' : 'media') : 'text'),
    created_at: new Date().toISOString(), status: 'sending'
  };
  state.forceScrollToBottom = true;
  mergeMessage(message);
  state.outbox.push({ matchId: state.activeMatch.matchId, clientId, content, attachments, attachmentKind: extras.kind || 'image', sticker, replyToId });
  state.replyTarget = null; if ($('#replyPreview')) $('#replyPreview').hidden = true;
  persistOutbox();
  saveDraft('');
  if (!state.socket?.connected) {
    showToast('Нет соединения. Сообщение в очереди и отправится после переподключения.');
    return;
  }
  flushOutbox();
}
function flushOutbox() {
  if (!state.socket?.connected || !state.activeMatch || !state.outbox.length) return;
  const pending = [...state.outbox];
  if (state.activeMatch.isAi) {
    pending.forEach(item => {
      if (item.matchId !== state.activeMatch?.matchId) return;
      state.socket.emit('ai:send', { sessionId: item.matchId, clientId: item.clientId, content: item.content, sticker: item.sticker || null, attachments: item.attachments || [] }, result => {
        const index = state.outbox.findIndex(row => row.clientId === item.clientId);
        const optimistic = state.messages.find(row => row.client_id === item.clientId);
        if (!result?.ok) {
          if (optimistic) { optimistic.status = 'failed'; renderMessages(); }
          showToast(result?.error || 'Не удалось отправить сообщение ИИ-собеседнику.');
        } else if (optimistic) {
          optimistic.status = undefined;
          renderMessages();
        }
        if (index >= 0) state.outbox.splice(index, 1);
        persistOutbox();
      });
    });
    return;
  }
  pending.forEach(item => {
    if (item.matchId !== state.activeMatch?.matchId) return;
    state.socket.emit('chat:send', { matchId: item.matchId, clientId: item.clientId, content: item.content, attachments: item.attachments || [], sticker: item.sticker || null, replyToId: item.replyToId || null }, result => {
      const index = state.outbox.findIndex(row => row.clientId === item.clientId);
      if (!result?.ok) {
        const failed = state.messages.find(row => row.client_id === item.clientId);
        if (failed) { failed.status = 'failed'; renderMessages(); }
        if (index >= 0) state.outbox.splice(index, 1);
        persistOutbox();
        showToast(result?.error || 'Не удалось отправить сообщение.');
      } else {
        if (index >= 0) state.outbox.splice(index, 1);
        persistOutbox();
        if (result.message) mergeMessage(result.message);
      }
    });
  });
}
function outboxKey() { return state.user ? `orbit_outbox_${state.user.id}` : ''; }
function persistOutbox() {
  if (!outboxKey()) return;
  try { safeStorageSet(outboxKey(), JSON.stringify(state.outbox)); } catch { /* local storage may be unavailable */ }
}
function restoreOutbox() {
  if (!outboxKey() || !state.activeMatch) return;
  try {
    const saved = JSON.parse(safeStorageGet(outboxKey()) || '[]');
    state.outbox = Array.isArray(saved) ? saved.filter(item => item && item.matchId === state.activeMatch.matchId && typeof item.clientId === 'string' && typeof item.content === 'string' && (Array.isArray(item.attachments) || typeof item.sticker === 'string' || item.content.length > 0)) : [];
    state.outbox.forEach(item => {
      if (!state.messages.some(message => message.client_id === item.clientId)) {
        state.messages.push({ id: `pending:${item.clientId}`, match_id: item.matchId, sender_id: state.user.id, client_id: item.clientId, content: item.content, attachments: (item.attachments || []).map(id => ({ id, kind: item.attachmentKind || 'image', url: '' })), sticker: item.sticker || null, type: item.sticker ? 'sticker' : 'text', created_at: new Date().toISOString(), status: 'sending' });
      }
    });
    renderMessages();
  } catch { state.outbox = []; }
}
function draftKey() { return state.user ? `orbit_draft_${state.user.id}` : ''; }
function saveDraft(value) {
  if (!draftKey()) return;
  try { safeStorageSet(draftKey(), JSON.stringify({ matchId: state.activeMatch?.matchId || null, text: value })); }
  catch { /* local storage may be unavailable */ }
}
function restoreDraft() {
  if (!draftKey() || !state.activeMatch) return;
  try {
    const draft = JSON.parse(safeStorageGet(draftKey()) || 'null');
    if (draft?.matchId === state.activeMatch.matchId && typeof draft.text === 'string') $('#messageInput').value = draft.text;
    else safeStorageRemove(draftKey());
  } catch { /* ignore malformed draft */ }
}
function retryMessage(message) {
  const item = state.messages.find(row => row.client_id === message.client_id);
  if (item) { item.status = 'sending'; renderMessages(); }
  if (!state.activeMatch) {
    if (item) { item.status = 'failed'; renderMessages(); }
    showToast('Этот диалог уже завершён.');
    return;
  }
  if (!state.outbox.some(row => row.clientId === message.client_id)) {
    state.outbox.push({ matchId: state.activeMatch.matchId, clientId: message.client_id, content: message.content, attachments: (message.attachments || []).map(item => item.id), attachmentKind: message.attachments?.[0]?.kind || 'image', sticker: message.sticker || null });
    persistOutbox();
  }
  if (!state.socket?.connected) { showToast('Повтор отправится после восстановления соединения.'); return; }
  flushOutbox();
}
async function uploadMedia(blob, kind) {
  if (!state.activeMatch || !state.token) throw new Error('Сначала найди собеседника.');
  const response = await fetch('/api/media/upload', {
    method: 'POST',
    headers: { Authorization: `Bearer ${state.token}`, 'Content-Type': blob.type, 'X-Match-Id': state.activeMatch.matchId, 'X-Media-Kind': kind },
    body: blob
  });
  let payload = {};
  try { payload = await response.json(); } catch { /* server returned an unexpected response */ }
  if (!response.ok) throw new Error(payload.error || `Не удалось загрузить файл (${response.status}).`);
  return payload.file;
}
function setUploadStatus(text) { $('#uploadStatus').textContent = text; }
async function sendSelectedPhotos(files) {
  if (!state.activeMatch) return showToast('Сначала найди собеседника.');
  const tier = state.user?.subscriptionTier || 'free';
  const attachmentLimit = tier === 'premium' ? 10 : (tier === 'vip' ? 5 : 3);
  const selected = [...files].slice(0, attachmentLimit);
  if (!selected.length) return;
  if (files.length > attachmentLimit) showToast(`За один раз можно отправить не больше ${attachmentLimit} фотографий.`);
  const uploaded = [];
  $('#photoButton').disabled = true;
  try {
    for (let index = 0; index < selected.length; index += 1) {
      const file = selected[index];
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error('Поддерживаются только JPG, PNG и WebP.');
      const tier = state.user?.subscriptionTier || 'free';
       const imageLimit = tier === 'premium' ? 12 : (tier === 'vip' ? 8 : 6);
       if (file.size > imageLimit * 1024 * 1024) throw new Error(`Каждая фотография должна быть не больше ${imageLimit} МБ для твоего статуса.`);
      setUploadStatus(`Загружаем ${index + 1}/${selected.length}…`);
      uploaded.push(await uploadMedia(file, 'image'));
    }
    sendMessage('', crypto.randomUUID(), { attachments: uploaded.map(item => item.id) });
    showToast(uploaded.length === 1 ? 'Фото отправлено.' : `Отправлено фотографий: ${uploaded.length}.`);
  } catch (error) {
    await Promise.all(uploaded.map(file => fetch(`/api/media/${encodeURIComponent(file.id)}`, { method: 'DELETE', headers: { Authorization: `Bearer ${state.token}` } }).catch(() => {})));
    showToast(error.message);
  }
  finally { $('#photoButton').disabled = false; setUploadStatus(''); $('#photoInput').value = ''; }
}
function clearVoiceRecording() {
  if (state.voiceTimer) clearInterval(state.voiceTimer);
  state.voiceTimer = null;
  if (state.voiceStream) state.voiceStream.getTracks().forEach(track => track.stop());
  state.voiceStream = null;
  state.mediaRecorder = null;
  state.voiceChunks = [];
  state.voiceBlob = null;
  state.voiceStartedAt = 0;
  if (state.voicePreviewUrl) URL.revokeObjectURL(state.voicePreviewUrl);
  state.voicePreviewUrl = null;
  $('#voicePreview').removeAttribute('src');
  $('#voicePreview').hidden = true;
  $('#voiceRecordPanel').hidden = true;
  $('#voiceButton').querySelector('.composer-label').textContent = 'Голосовое';
  $('#voiceButton').classList.remove('recording');
  $('#voiceSendButton').disabled = true;
  $('#voiceRecordLabel').textContent = 'Идёт запись';
  $('#recordingTimer').textContent = '00:00';
}
function stopVoiceRecording(discard = false) {
  state.discardVoice = discard;
  if (state.voiceTimer) clearInterval(state.voiceTimer);
  state.voiceTimer = null;
  if (state.activeMatch && state.socket?.connected) state.socket.emit('chat:recording', { matchId: state.activeMatch.matchId, recording: false });
  if (state.mediaRecorder && state.mediaRecorder.state !== 'inactive') {
    state.mediaRecorder.stop();
    state.voiceStream?.getTracks().forEach(track => track.stop());
    return;
  }
  clearVoiceRecording();
}
async function startVoiceRecording() {
  if (state.voiceBlob || state.voicePreviewUrl) clearVoiceRecording();
  if (!state.activeMatch) return showToast('Сначала найди собеседника.');
  if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
    return showToast('Микрофон доступен через HTTPS или localhost. Открой безопасное соединение.');
  }
  try {
    state.discardVoice = false;
    state.voiceStream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, sampleRate: 48000, echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
    const candidates = ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/mp4'];
    const mimeType = candidates.find(type => { try { return MediaRecorder.isTypeSupported(type); } catch { return false; } });
    state.mediaRecorder = new MediaRecorder(state.voiceStream, mimeType ? { mimeType, audioBitsPerSecond: 48000 } : { audioBitsPerSecond: 48000 });
    state.voiceChunks = [];
    state.voiceStartedAt = Date.now();
    state.mediaRecorder.addEventListener('dataavailable', event => { if (event.data?.size) state.voiceChunks.push(event.data); });
    state.mediaRecorder.addEventListener('error', () => { state.discardVoice = true; clearVoiceRecording(); showToast('Браузер прервал запись. Попробуй ещё раз.'); }, { once: true });
    state.mediaRecorder.addEventListener('stop', () => {
      state.voiceStream?.getTracks().forEach(track => track.stop());
      state.voiceStream = null;
      if (state.discardVoice) { clearVoiceRecording(); return; }
      const rawType = state.mediaRecorder?.mimeType || state.voiceChunks[0]?.type || 'audio/webm';
      const type = rawType.toLowerCase().includes('ogg') ? 'audio/ogg' : (rawType.toLowerCase().includes('mp4') ? 'audio/mp4' : 'audio/webm');
      state.voiceBlob = new Blob(state.voiceChunks, { type });
      if (!state.voiceBlob.size) { clearVoiceRecording(); return showToast('Не удалось записать голосовое.'); }
      state.voicePreviewUrl = URL.createObjectURL(state.voiceBlob);
      $('#voicePreview').src = state.voicePreviewUrl;
      $('#voicePreview').hidden = false;
      $('#voiceRecordLabel').textContent = 'Прослушай запись перед отправкой';
      $('#voiceSendButton').disabled = false;
      $('#voiceButton').querySelector('.composer-label').textContent = 'Голосовое';
  $('#voiceButton').classList.remove('recording');
    }, { once: true });
    state.mediaRecorder.start(250);
    state.socket?.emit('chat:recording', { matchId: state.activeMatch.matchId, recording: true });
    $('#voiceRecordPanel').hidden = false;
    $('#voicePreview').hidden = true;
    $('#voiceRecordLabel').textContent = 'Идёт запись';
    $('#voiceSendButton').disabled = true;
    $('#voiceButton').querySelector('.composer-label').textContent = 'Остановить';
    $('#voiceButton').classList.add('recording');
    state.voiceTimer = setInterval(() => {
      const seconds = Math.floor((Date.now() - state.voiceStartedAt) / 1000);
      $('#recordingTimer').textContent = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
      const tier = state.user?.subscriptionTier || 'free';
      const voiceLimit = tier === 'premium' ? 60 : (tier === 'vip' ? 45 : 30);
      if (seconds >= voiceLimit) { stopVoiceRecording(false); showToast(`Достигнут лимит голосового — ${Math.floor(voiceLimit / 60)}:${String(voiceLimit % 60).padStart(2, '0')}.`); }
    }, 250);
  } catch (error) {
    clearVoiceRecording();
    showToast(error.name === 'NotAllowedError' ? 'Разреши доступ к микрофону в браузере.' : 'Не удалось включить микрофон. Проверь его подключение и HTTPS.');
  }
}
async function sendVoiceRecording() {
  if (!state.voiceBlob || !state.activeMatch) return;
  $('#voiceSendButton').disabled = true;
  setUploadStatus('Загружаем голосовое…');
  try {
    const file = await uploadMedia(state.voiceBlob, 'audio');
    sendMessage('', crypto.randomUUID(), { attachments: [file.id], kind: 'audio' });
    clearVoiceRecording();
    showToast('Голосовое добавлено в очередь отправки.');
  } catch (error) { $('#voiceSendButton').disabled = false; showToast(error.message); }
  finally { setUploadStatus(''); }
}
function renderStickerPanel() {
  const panel = $('#stickerPanel');
  panel.replaceChildren();
  const base = state.config.stickers || ['👋', '😂', '❤️', '🔥', '🥹', '🎉', '☕', '🐈'];
  const pack = STICKER_PACKS[state.user?.equipped?.stickers] || [];
  [...base, ...pack].forEach(sticker => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'sticker-choice';
    button.textContent = sticker;
    button.setAttribute('aria-label', `Отправить стикер ${sticker}`);
    button.addEventListener('click', () => {
      sendMessage('', crypto.randomUUID(), { sticker });
      panel.hidden = true;
    });
    panel.append(button);
  });
}

async function submitReport() {
  $('#reportError').textContent = '';
  try {
    await api('/api/report', { method: 'POST', body: JSON.stringify({ category: $('#reportCategory').value, details: $('#reportDetails').value }) });
    closeModals();
    showToast('Жалоба отправлена. Спасибо, что помогаешь сохранять безопасность.');
  } catch (error) { $('#reportError').textContent = error.message; }
}
async function blockPartner() {
  if (!await appDialog({title:'Заблокировать собеседника?',message:'Диалог завершится, и вы больше не попадёте друг к другу в подбор.',confirmText:'Заблокировать',danger:true})) return;
  try {
    await api('/api/block', { method: 'POST', body: '{}' });
    showToast('Пользователь заблокирован.');
  } catch (error) { showToast(error.message); }
}
function closeModals() {
  state.storePreviewItem = null;
  $$('.modal-backdrop').forEach(modal => { modal.hidden = true; });
  document.body.classList.remove('store-preview-open', 'purchase-confirm-open');
}
function logout(showMessage = true, revokeServer = true) {
  const oldToken = state.token;
  if (revokeServer && oldToken) fetch('/api/auth/logout', { method: 'POST', headers: { Authorization: `Bearer ${oldToken}` } }).catch(() => {});
  clearSearchTimer();
  state.searching = false;
  if (state.socket) { state.socket.disconnect(); state.socket = null; }
  releaseMediaUrls();
  stopVoiceRecording(true);
  safeStorageRemove('sovli_token');
  safeStorageRemove('orbit_token');
  safeStorageRemove('sovli_user_cache');
  state.token = '';
  state.user = null;
  state.activeMatch = null;
  state.messages = [];
  state.favorites = [];
  state.tokenHistoryLoaded = false;
  state.replyTarget = null;
  if ($('#replyPreview')) { $('#replyPreview').hidden = true; $('#replyPreview').querySelector('span').textContent = ''; }
  state.outbox = [];
  showAuth();
  if (showMessage) showToast('Ты вышел из аккаунта.');
}
function applyTheme() {
  const themeId = document.documentElement.dataset.storeTheme || state.user?.equipped?.theme || 'theme-light';
  const darkThemes = new Set(['theme-dark','theme-midnight','theme-aurora','theme-arcade','theme-violet-royal','wallpaper-deep-space','wallpaper-neon-city','wallpaper-cyber','wallpaper-pixel','wallpaper-arcade']);
  const resolved = darkThemes.has(themeId) ? 'dark' : 'light';
  document.documentElement.dataset.theme = resolved;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = getComputedStyle(document.documentElement).getPropertyValue('--bg').trim() || (resolved === 'dark' ? '#181827' : '#f5f6fb');
}
function renderSettingsControls() {
  const settings = state.settings;
  if ($('#settingSounds')) $('#settingSounds').checked = settings.sounds;
  if ($('#settingSoundVolume')) $('#settingSoundVolume').value = String(settings.soundVolume);
  if ($('#soundVolumeLabel')) $('#soundVolumeLabel').textContent = `${settings.soundVolume}%`;
  if ($('#settingMessageScale')) $('#settingMessageScale').value = settings.messageScale;
  if ($('#settingReducedMotion')) $('#settingReducedMotion').checked = settings.reducedMotion;
  if ($('#settingEnterToSend')) $('#settingEnterToSend').checked = settings.enterToSend !== false;
  if ($('#settingCompactChat')) $('#settingCompactChat').checked = Boolean(settings.compactChat);
  if ($('#settingBrowserNotifications')) $('#settingBrowserNotifications').checked = Boolean(settings.browserNotifications);
}
function applySettings() {
  applyTheme(state.settings.theme);
  const messages = $('#messages');
  if (messages) messages.dataset.messageScale = state.settings.messageScale;
  document.documentElement.classList.toggle('reduce-motion-user', Boolean(state.settings.reducedMotion));
  document.documentElement.classList.toggle('compact-chat-user', Boolean(state.settings.compactChat));
}
function scheduleSettingsSave(patch) {
  state.settings = { ...state.settings, ...patch };
  renderSettingsControls();
  applySettings();
  $('#settingsSaveStatus').textContent = 'Сохраняем…';
  clearTimeout(state.settingsSaveTimer);
  state.settingsSaveTimer = setTimeout(async () => {
    try {
      const result = await api('/api/settings', { method: 'PATCH', body: JSON.stringify(state.settings) });
      state.settings = { ...state.settings, ...result.settings };
      renderSettingsControls();
      applySettings();
      $('#settingsSaveStatus').textContent = 'Сохранено в аккаунте';
    } catch (error) {
      $('#settingsSaveStatus').textContent = 'Не удалось сохранить';
      showToast(error.message);
    }
  }, 350);
}
function playUiSound(frequency = 520) {
  if (!state.settings.sounds || state.settings.soundVolume <= 0) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    state.soundContext ||= new AudioContextClass();
    if (state.soundContext.state === 'suspended') state.soundContext.resume();
    const oscillator = state.soundContext.createOscillator();
    const gain = state.soundContext.createGain();
    const now = state.soundContext.currentTime;
    gain.gain.setValueAtTime(Math.max(0.0001, state.settings.soundVolume / 100 * 0.045), now);
    const soundStyle = state.user?.equipped?.sound;
    const soundProfiles = {
      'sound-soft-pop': { type: 'triangle', ratio: 0.78, duration: 0.11 },
      'sound-orbit-chime': { type: 'sine', ratio: 1.45, duration: 0.22 },
      'sound-arcade': { type: 'square', ratio: 1.8, duration: 0.09 },
      'sound-royal': { type: 'sine', ratio: 1.22, duration: 0.28 },
      'sound-rain': { type: 'triangle', ratio: 0.65, duration: 0.2 },
      'sound-bubble': { type: 'sine', ratio: 1.1, duration: 0.12 },
      'sound-synth': { type: 'sawtooth', ratio: 1.32, duration: 0.16 }
    };
    const profile = soundProfiles[soundStyle] || { type: 'sine', ratio: 1, duration: 0.14 };
    gain.gain.exponentialRampToValueAtTime(0.0001, now + profile.duration);
    oscillator.type = profile.type;
    oscillator.frequency.setValueAtTime(frequency, now);
    oscillator.frequency.linearRampToValueAtTime(frequency * profile.ratio, now + profile.duration * 0.55);
    oscillator.connect(gain);
    gain.connect(state.soundContext.destination);
    oscillator.start(now);
    oscillator.stop(now + profile.duration + 0.02);
  } catch { /* Audio is optional and may be blocked by the browser. */ }
}
async function boot() {
  const bootScreen = $('#sessionBootScreen');
  let cachedUser = null;
  try {
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
    applyTheme();
    if (state.token) {
      try { cachedUser = JSON.parse(safeStorageGet('sovli_user_cache') || 'null'); } catch { cachedUser = null; }
      if (cachedUser?.id) { setUser(cachedUser); showApp(); }
    }
    if (bootScreen) bootScreen.hidden = !state.token || Boolean(cachedUser?.id);
    try { state.config = await api('/api/config'); }
    catch {
      state.config = { languages: ['Русский'], interests: [], avatars: ['🪐', '🌙', '🦊', '🐼'], matchingEnabled: true, publicMode: false, socialLinks: [] };
    }
    renderSocialLinks();
    const billingResult = new URL(window.location.href).searchParams.get('billing');
    if (billingResult === 'success' && state.token) {
      try { const latest = await api('/api/me'); setUser(latest.user); showToast('Платёж принят. Если Stripe ещё отправляет подтверждение, статус активируется автоматически.'); }
      catch { showToast('Платёж завершён. Статус обновится после подтверждения платёжного сервиса.'); }
      history.replaceState({}, '', window.location.pathname + window.location.hash);
    } else if (billingResult === 'cancelled') {
      showToast('Оплата отменена. Списание не выполнено.');
      history.replaceState({}, '', window.location.pathname + window.location.hash);
    }
    const tier = state.user?.subscriptionTier || 'free';
    const languageLimit = tier === 'premium' ? 10 : (tier === 'vip' ? 5 : 3);
    const interestLimit = tier === 'premium' ? 12 : (tier === 'vip' ? 8 : 5);
    if (Array.isArray(state.config.languages)) {
      state.selectedLanguages = state.selectedLanguages.filter(value => state.config.languages.includes(value)).slice(0, languageLimit);
    } else state.selectedLanguages = [];
    if (Array.isArray(state.config.interests)) {
      state.selectedInterests = state.selectedInterests.filter(value => state.config.interests.includes(value)).slice(0, interestLimit);
    } else state.selectedInterests = [];renderFilters();
    renderStickerPanel();
    $('#inviteCodeField').hidden = !state.config.inviteRequired;
    if (state.config.inviteRequired) $('#authInviteCode').required = true;
    if (state.config.matchingEnabled === false) {
      $('#findButton').disabled = true;
      $('#findButton').title = 'Подбор временно недоступен';
    }
    if (!state.token) { showAuth(); return; }
    state.authRestoring = true;
    try {
      const response = await api('/api/me');
      setUser(response.user);
      state.activeMatch = response.activeMatch;
      showApp();
      loadFavorites();
      connectSocket();
    } catch (error) {
      if (error.status === 401) {
        safeStorageRemove('sovli_user_cache');
        logout(false);
        if (error.message?.includes('гостевого')) setAuthError(error.message);
      } else if (cachedUser?.id) {
        showApp();
        connectSocket();
        showToast('Восстанавливаем связь с сервером. Аккаунт сохранён.');
      } else {
        showAuth();
        setAuthError('Не удалось проверить сессию из-за временной ошибки связи. Обнови страницу — повторный вход не нужен.');
      }
    }
  } catch (error) {
    console.error('[SOLVI] Ошибка запуска интерфейса:', error);
    if (cachedUser?.id) {
      try { setUser(cachedUser); } catch (cacheError) { console.error('[SOLVI] Не удалось восстановить кеш профиля:', cacheError); }
      showApp();
      showToast('Интерфейс открылся в режиме восстановления. Обнови страницу, когда связь восстановится.');
    } else {
      showAuth();
      setAuthError('Не удалось запустить интерфейс. Обнови страницу; повторная регистрация не нужна.');
    }
  } finally {
    state.authRestoring = false;
    if (bootScreen) bootScreen.hidden = true;
    document.documentElement.classList.remove('session-checking');
  }
}

$('#authForm').addEventListener('submit', async event => {
  event.preventDefault();
  setAuthError('');
  const username = $('#authUsername').value.trim();
  const password = $('#authPassword').value;
  const isRegister = state.authMode === 'register';
  if (username.length < 3 || username.length > 20) { setAuthError('Ник должен содержать от 3 до 20 символов.'); return; }
  if (password.length < 8) { setAuthError('Пароль должен содержать не менее 8 символов.'); return; }
  const button = $('#authSubmit');
  button.disabled = true;
  button.querySelector('span:first-child').textContent = isRegister ? 'Создаём аккаунт…' : 'Входим…';
  try {
    const response = await api(isRegister ? '/api/auth/register' : '/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password, accessCode: $('#authInviteCode').value.trim() })
    });
    state.token = response.token;
    safeStorageSet('sovli_token', state.token);
    safeStorageRemove('orbit_token');
    setUser(response.user);
    showApp();
    connectSocket();
    loadFavorites();
    showToast(isRegister ? 'Аккаунт создан. Теперь входи по никнейму и паролю.' : 'С возвращением!', 5000);
  } catch (error) { setAuthError(error.message); }
  finally {
    button.disabled = false;
    button.querySelector('span:first-child').textContent = isRegister ? 'Создать аккаунт' : 'Войти в SOLVI';
  }
});
$$('[data-auth-tab]').forEach(button => button.addEventListener('click', () => switchAuthMode(button.dataset.authTab)));
$('#guestButton').addEventListener('click', async () => {
  const button = $('#guestButton');
  button.disabled = true;
  button.querySelector('span:first-child').textContent = 'Готовим гостевой профиль…';
  setAuthError('');
  try {
    const response = await api('/api/auth/guest', { method: 'POST', body: JSON.stringify({ accessCode: $('#authInviteCode').value.trim() }) });
    state.token = response.token;
    safeStorageSet('sovli_token', state.token);
    safeStorageRemove('orbit_token');
    setUser(response.user);
    showApp();
    connectSocket();
    loadFavorites();
    showToast(`Привет, ${response.user.username}! Гостевой профиль действует 3 дня в этом браузере.`);
  } catch (error) { setAuthError(error.message); }
  finally { button.disabled = false; button.querySelector('span:first-child').textContent = 'Продолжить гостем'; }
});
$('#desiredGenderChoices')?.addEventListener('click', event => {
  const button = event.target.closest('[data-gender-target="desired"][data-gender]');
  if (!button) return;
  state.desiredGender = button.dataset.gender;
  renderFilters();
});
$('#ownGenderChoices')?.addEventListener('click', event => {
  const button = event.target.closest('[data-gender-target="own"][data-gender]');
  if (!button) return;
  state.ownGender = button.dataset.gender;
  renderGenderChoices();
});
$('#findButton').addEventListener('click', startSearch);
$('#clearFiltersButton').addEventListener('click', () => { state.selectedLanguages = []; state.selectedInterests = []; state.desiredGender = 'any'; if ($('#languagesDropdown')) $('#languagesDropdown').open = false; if ($('#interestsDropdown')) $('#interestsDropdown').open = false; renderFilters(); showToast('Фильтры сброшены.'); });
$('#nextChatButton').addEventListener('click', nextPartner);
$('#cancelSearchButton').addEventListener('click', cancelSearch);
$('#expandSearchButton').addEventListener('click', () => {
  state.selectedLanguages = [];
  state.selectedInterests = [];
  renderFilters();
  state.searching = false;
  state.socket?.emit('queue:cancel');
  clearSearchTimer();
  setTimeout(() => startSearch(), 120);
});
$('#logoutButton').addEventListener('click', () => logout());
$('#profileTopButton').addEventListener('click', () => setView('profile'));
$('#settingsTopButton').addEventListener('click', () => setView('settings'));
$('#sidePublicId').addEventListener('click', async () => {
  if (!state.user) return;
  try { await navigator.clipboard.writeText(state.user.publicId); showToast('Технический ID скопирован. Для входа используй ник и пароль.'); }
  catch { showToast(`Твой ID: ${state.user.publicId}`); }
});
document.addEventListener('click', event => {
  const button = event.target?.closest?.('[data-view]');
  if (!button) return;
  if (button.tagName === 'A') event.preventDefault();
  setView(button.dataset.view, button.id === 'brandHomeLink');
}, true);
$('#settingSounds').addEventListener('change', () => scheduleSettingsSave({ sounds: $('#settingSounds').checked }));
$('#settingSoundVolume').addEventListener('input', () => { $('#soundVolumeLabel').textContent = `${$('#settingSoundVolume').value}%`; });
$('#settingSoundVolume').addEventListener('change', () => scheduleSettingsSave({ soundVolume: Number($('#settingSoundVolume').value) }));
$('#settingMessageScale').addEventListener('change', () => scheduleSettingsSave({ messageScale: $('#settingMessageScale').value }));
$('#settingReducedMotion').addEventListener('change', () => scheduleSettingsSave({ reducedMotion: $('#settingReducedMotion').checked }));
$('#settingEnterToSend').addEventListener('change', () => scheduleSettingsSave({ enterToSend: $('#settingEnterToSend').checked }));
$('#settingCompactChat').addEventListener('change', () => scheduleSettingsSave({ compactChat: $('#settingCompactChat').checked }));
$('#settingBrowserNotifications').addEventListener('change', async () => {
  if ($('#settingBrowserNotifications').checked) {
    if (!('Notification' in window)) { $('#settingBrowserNotifications').checked = false; showToast('Этот браузер не поддерживает уведомления.'); return; }
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') { $('#settingBrowserNotifications').checked = false; showToast('Разрешение на уведомления не выдано.'); return; }
  }
  scheduleSettingsSave({ browserNotifications: $('#settingBrowserNotifications').checked });
});
window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change', () => { if (state.settings.theme === 'system') applyTheme('system'); });
$('#rulesFooterButton').addEventListener('click', () => { $('#rulesModal').hidden = false; });
$('#authRulesButton').addEventListener('click', () => { $('#rulesModal').hidden = false; });
$$('[data-close-modal]').forEach(button => button.addEventListener('click', closeModals));
$$('.modal-backdrop').forEach(modal => modal.addEventListener('click', event => { if (event.target === modal) closeModals(); }));
$('#endChatButton').addEventListener('click', async () => {
  if (!state.activeMatch) return;
  if (!await appDialog({title:'Завершить диалог?',message:'После завершения ты сможешь сохранить текст переписки в Избранное.',confirmText:'Завершить',danger:true})) return;
  state.socket?.emit('chat:end', { matchId: state.activeMatch.matchId }, result => {
    if (!result?.ok) showToast(result?.error || 'Не удалось завершить диалог.');
  });
});
$('#reportButton').addEventListener('click', () => { $('#reportDetails').value = ''; $('#reportError').textContent = ''; $('#reportModal').hidden = false; });
$('#submitReportButton').addEventListener('click', submitReport);
$('#blockButton').addEventListener('click', blockPartner);
$('#cancelReplyButton')?.addEventListener('click', () => { state.replyTarget = null; $('#replyPreview').hidden = true; $('#replyPreview').querySelector('span').textContent = ''; });
$$('[data-quick-reply]').forEach(button => button.addEventListener('click', () => { const text = button.dataset.quickReply; sendMessage(text, crypto.randomUUID()); $('#quickReplies').open = false; }));
$('#storeInventoryButton')?.addEventListener('click', () => { state.storeCollectionOnly = !state.storeCollectionOnly; if (state.storeData) renderStore(state.storeData); });
$('#storeCollectionSelect')?.addEventListener('change', () => { state.storeCollectionFilter = $('#storeCollectionSelect').value; if (state.storeData) renderStore(state.storeData); });
$('#storeSearchInput')?.addEventListener('input', () => { state.storeSearch = $('#storeSearchInput').value; if (state.storeData) renderStore(state.storeData); });
$('#promoRedeemButton')?.addEventListener('click', redeemPromo);
$('#promoCodeInput')?.addEventListener('keydown', event => { if (event.key === 'Enter') redeemPromo(); });
$('#loadSessionsButton')?.addEventListener('click', loadSessions);
$('#ticketCreateForm')?.addEventListener('submit', async event => {
  event.preventDefault();
  const button = $('#ticketCreateButton'); button.disabled = true;
  try {
    const result = await api('/api/tickets', { method: 'POST', body: JSON.stringify({ category: $('#ticketCategory').value, title: $('#ticketTitle').value, body: $('#ticketBody').value }) });
    $('#ticketCreateForm').reset(); showToast('Обращение отправлено. Ответ появится в этой вкладке.');
    await loadTickets(); await openTicket(result.id);
  } catch (error) { showToast(error.message); }
  finally { button.disabled = false; }
});
$('#ticketReplyForm')?.addEventListener('submit', async event => {
  event.preventDefault(); if (!state.activeTicketId) return;
  const button = $('#ticketReplyButton'); button.disabled = true;
  try {
    await api(`/api/tickets/${encodeURIComponent(state.activeTicketId)}/messages`, { method: 'POST', body: JSON.stringify({ body: $('#ticketReplyInput').value }) });
    $('#ticketReplyInput').value = ''; await openTicket(state.activeTicketId); await loadTickets();
  } catch (error) { showToast(error.message); }
  finally { button.disabled = false; }
});
$('#favoriteChatClose')?.addEventListener('click', () => { $('#favoriteChatModal').hidden = true; });
$('#ticketCloseButton')?.addEventListener('click',async()=>{if(!state.activeTicketId)return;if(!await appDialog({title:'Закрыть обращение?',message:'Если проблема вернётся, можно будет создать новый тикет.',confirmText:'Закрыть'}))return;try{await api('/api/tickets/'+encodeURIComponent(state.activeTicketId)+'/close',{method:'POST',body:'{}'});await openTicket(state.activeTicketId);await loadTickets();showToast('Тикет закрыт.');}catch(error){showToast(error.message);}});



$('#messageForm').addEventListener('submit', event => {
  event.preventDefault();
  const input = $('#messageInput');
  const content = input.value.trim();
  if (!content) return;
  const messageLimit = state.user?.subscriptionTier === 'premium' ? 5000 : (state.user?.subscriptionTier === 'vip' ? 3000 : 2000);
  if (content.length > messageLimit) { showToast(`Сообщение слишком длинное. Лимит: ${messageLimit.toLocaleString('ru-RU')} символов.`); return; }
  const clientId = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  sendMessage(content, clientId);
  $('#stickerPanel').hidden = true;
  input.value = '';
  saveDraft('');
  input.style.height = 'auto';
  state.socket?.emit('chat:typing', { matchId: state.activeMatch?.matchId, typing: false });
});
$('#messageInput').addEventListener('input', () => {
  const input = $('#messageInput');
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 110)}px`;
  saveDraft(input.value);
  if (!state.activeMatch || !state.socket?.connected) return;
  const now = Date.now();
  if (now - state.lastTypingSentAt >= 450) { state.lastTypingSentAt = now; state.socket.emit('chat:typing', { matchId: state.activeMatch.matchId, typing: true }); }
  clearTimeout(state.typingTimer);
  state.typingTimer = setTimeout(() => { state.socket?.emit('chat:typing', { matchId: state.activeMatch?.matchId, typing: false }); state.lastTypingSentAt = 0; }, 1500);
});
$('#messageInput').addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey && state.settings.enterToSend !== false) { event.preventDefault(); $('#messageForm').requestSubmit(); }
});
$('#photoButton').addEventListener('click', () => $('#photoInput').click());
$('#photoInput').addEventListener('change', () => sendSelectedPhotos($('#photoInput').files));
$('#stickerButton').addEventListener('click', () => { $('#stickerPanel').hidden = !$('#stickerPanel').hidden; });
$('#voiceButton').addEventListener('click', () => { if (state.mediaRecorder && state.mediaRecorder.state !== 'inactive') stopVoiceRecording(false); else startVoiceRecording(); });
$('#voiceDiscardButton').addEventListener('click', () => stopVoiceRecording(true));
$('#voiceSendButton').addEventListener('click', sendVoiceRecording);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') markRead(); });
window.addEventListener('focus', markRead);
$('#profileUsername').addEventListener('input', () => { $('#profilePreviewName').textContent = $('#profileUsername').value || state.user?.username || ''; });
$('#saveProfileButton').addEventListener('click', async () => {
  const button = $('#saveProfileButton');
  button.disabled = true;
  try {
    const profilePatch = { username: $('#profileUsername').value };
    if (state.selectedAvatar) profilePatch.avatar = state.selectedAvatar;
    const result = await api('/api/profile', { method: 'PATCH', body: JSON.stringify(profilePatch) });
    setUser(result.user);
    showToast('Профиль обновлён.');
  } catch (error) { showToast(error.message); }
  finally { button.disabled = false; }
});
$('#avatarUploadButton').addEventListener('click', () => $('#avatarFileInput').click());
$('#avatarFileInput').addEventListener('change', async () => {
  const file = $('#avatarFileInput').files?.[0]; if (!file) return;
  const button = $('#avatarUploadButton');
  if (!['image/jpeg','image/png','image/webp'].includes(file.type)) { showToast('Поддерживаются JPG, PNG и WebP.'); $('#avatarFileInput').value = ''; return; }
  const tier = state.user?.subscriptionTier || 'free';
  const avatarLimit = tier === 'premium' ? 12 : (tier === 'vip' ? 8 : 4);
  if (file.size > avatarLimit * 1024 * 1024) { showToast(`Аватар должен быть не больше ${avatarLimit} МБ для твоего статуса.`); $('#avatarFileInput').value = ''; return; }
  button.disabled = true; button.textContent = 'Загружаем…';
  try {
    const response = await fetch('/api/avatar/upload', { method: 'POST', headers: { Authorization: `Bearer ${state.token}`, 'Content-Type': file.type }, body: file });
    const payload = await response.json(); if (!response.ok) throw new Error(payload.error || 'Не удалось загрузить аватар.');
    state.selectedAvatar = null; setUser(payload.user); showToast('Аватар обновлён.');
  } catch (error) { showToast(error.message); }
  finally { button.disabled = false; button.textContent = 'Загрузить своё фото'; $('#avatarFileInput').value = ''; }
});

$('#deleteAccountButton').addEventListener('click', async () => {
  if (!await appDialog({title:'Удалить аккаунт?',message:'Аккаунт и связанные данные будут удалены без возможности восстановления.',confirmText:'Продолжить',danger:true})) return;
  const confirmation=await appDialog({title:'Последнее подтверждение',message:'Это действие нельзя отменить. Ты действительно хочешь удалить аккаунт?',confirmText:'Удалить аккаунт',danger:true});
  if (!confirmation) return;
  try {
    await api('/api/account', { method: 'DELETE' });
    logout(false);
    showToast('Аккаунт удалён.');
  } catch (error) { showToast(error.message); }
});

switchAuthMode('login');
boot();
